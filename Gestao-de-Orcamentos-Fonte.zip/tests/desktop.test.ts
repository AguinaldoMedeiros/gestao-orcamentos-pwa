import { test } from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { createRequire } from 'node:module';
const require=createRequire(import.meta.url);
const {resolveAsset}=require('../desktop/assets.cjs');
test('Protocolo interno resolve aplicação e recursos sem servidor HTTP',()=>{
 assert.equal(resolveAsset('/app/dist','orcamentos://app/'),path.resolve('/app/dist/index.html'));
 assert.equal(resolveAsset('/app/dist','orcamentos://app/assets/app.js'),path.resolve('/app/dist/assets/app.js'));
});
test('Protocolo interno rejeita origens e caminhos externos',()=>{
 for(const url of ['https://example.com/','orcamentos://outro/','orcamentos://app/%2e%2e%2fsecret','orcamentos://app/%5csecret','orcamentos://app/%00','orcamentos://user@app/'])assert.throws(()=>resolveAsset('/app/dist',url));
});
