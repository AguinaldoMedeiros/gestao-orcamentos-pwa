import "fake-indexeddb/auto";
import { test } from "node:test";
import assert from "node:assert/strict";
import { PeerSync } from "../src/sync";
import { Ledger, defaultProject, uuid, type Op } from "../src/model";
class MemoryStore {
  ledger = new Ledger();
  onOps = new Set<(ops: Op[]) => void>();
  async accept(ops: Op[]) {
    let added = this.ledger.ingest(ops);
    if (added.length) this.onOps.forEach((fn) => fn(added));
    return added;
  }
}
class FakePC {
  connectionState = "connected";
  close() {}
  onconnectionstatechange: unknown;
  ondatachannel: unknown;
}
class Pipe {
  readyState = "open";
  label = "orcamentos-v1";
  bufferedAmount = 0;
  bufferedAmountLowThreshold = 0;
  other?: Pipe;
  onmessage?: (e: { data: string }) => void;
  onopen?: () => void;
  onclose?: () => void;
  onerror?: () => void;
  sent: string[] = [];
  send(data: string) {
    this.sent.push(data);
    queueMicrotask(() => this.other?.onmessage?.({ data }));
  }
  close() {
    this.readyState = "closed";
  }
  addEventListener() {}
  removeEventListener() {}
}
Object.assign(globalThis, {
  window: { RTCPeerConnection: FakePC },
  RTCPeerConnection: FakePC,
});
async function settle() {
  for (let n = 0; n < 20; n++) await new Promise((r) => setTimeout(r, 5));
}
test("Sincronização cifra, exige duas autorizações e replica alterações sem duplicar", async () => {
  let a = new MemoryStore(),
    b = new MemoryStore(),
    sa = new PeerSync(a),
    sb = new PeerSync(b);
  let p = defaultProject("Projeto distribuído");
  p.description = "Teste ".repeat(2500);
  await a.accept([a.ledger.create("A", "project", p.id, p)]);
  let secret = btoa("k".repeat(32)),
    id = uuid(),
    pa = await sa.createPeer(id, secret, "B"),
    pb = await sb.createPeer(id, secret, "A"),
    ca = new Pipe(),
    cb = new Pipe();
  ca.other = cb;
  cb.other = ca;
  sa.attach(pa, ca as unknown as RTCDataChannel);
  sb.attach(pb, cb as unknown as RTCDataChannel);
  sa.approve(id);
  await settle();
  assert.equal(
    b.ledger.ops.size,
    0,
    "Não envia dados sem autorização do receptor",
  );
  assert.ok(ca.sent.every((m) => JSON.parse(m).t === "approve"));
  sb.approve(id);
  await settle();
  assert.equal(b.ledger.snapshot().projects[0].name, p.name);
  assert.ok(ca.sent.some((m) => JSON.parse(m).t === "chunk"));
  assert.ok(
    !ca.sent.join("").includes("Projeto distribuído"),
    "Conteúdo cifrado no transporte",
  );
  let modified = { ...p, name: "Atualizado no B" };
  await b.accept([b.ledger.create("B", "project", p.id, modified)]);
  await settle();
  assert.equal(a.ledger.snapshot().projects[0].name, "Atualizado no B");
  assert.equal(a.ledger.ops.size, b.ledger.ops.size);
  assert.equal(a.ledger.ops.size, 2);
  sa.disconnectAll();
  sb.disconnectAll();
});
test("Código de pareamento malformado é rejeitado", () => {
  let s = new PeerSync(new MemoryStore());
  assert.throws(() => s.decode("inválido"));
  assert.throws(() => s.decode("a".repeat(150001)));
});
