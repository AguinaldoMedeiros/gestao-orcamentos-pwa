import "fake-indexeddb/auto";
import { test, after } from "node:test";
import assert from "node:assert/strict";
import { Store } from "../src/database";
import { defaultProject, type Project } from "../src/model";
after(() => {});
test("Banco persiste após uma nova instância e preserva edição causal antiga", async () => {
  let a = await new Store().init();
  a.channel?.close();
  a.channel = null;
  let p = defaultProject("Persistência");
  await a.write("project", p.id, p);
  let b = await new Store().init();
  b.channel?.close();
  b.channel = null;
  assert.equal(
    b.snapshot.projects.find((x) => x.id === p.id)?.name,
    "Persistência",
  );
  let stale = a.snapshot.projects.find((x) => x.id === p.id)!;
  let current = b.snapshot.projects.find((x) => x.id === p.id)!;
  await b.write(
    "project",
    p.id,
    { ...current, name: "Alterado no B" },
    current,
  );
  await a.reload();
  await a.write("project", p.id, { ...stale, name: "Alterado no A" }, stale);
  assert.equal(a.snapshot.conflicts.length, 1);
  let chosen = a.snapshot.projects.find((x) => x.id === p.id)!;
  await a.write("project", p.id, { ...chosen, name: "Resolvido" });
  assert.equal(a.snapshot.conflicts.length, 0);
});
test("Lote inválido não grava parcialmente", async () => {
  let s = await new Store().init();
  s.channel?.close();
  s.channel = null;
  let p = defaultProject("Não gravar");
  let before = s.ledger.ops.size;
  await assert.rejects(() =>
    s.batch([
      { entity: "project", key: p.id, value: p },
      {
        entity: "project",
        key: "bad",
        value: { ...p, id: "bad", name: "" } as Project,
      },
    ]),
  );
  assert.equal(s.ledger.ops.size, before);
});
