import { test } from "node:test";
import assert from "node:assert/strict";
import { mappedRecords } from "../src/io";
test("Importação exige data e método para criar o pagamento inicial", () => {
  let input = [
      {
        Descrição: "Serviço",
        Orçado: "1000",
        Pago: "100",
        Data: "",
        Método: "",
      },
    ],
    map = {
      description: "Descrição",
      budget: "Orçado",
      paid: "Pago",
      date: "Data",
      method: "Método",
    } as const;
  let result = mappedRecords("p", input, map);
  assert.equal(result.records.length, 1);
  assert.equal(result.warnings.length, 1);
  input[0].Data = "11/11/2026";
  input[0].Método = "Pix";
  result = mappedRecords("p", input, map);
  assert.equal(result.records.length, 2);
  assert.equal(result.warnings.length, 0);
});
test("Importação não cria pagamento excedente sem confirmação", () => {
  let result = mappedRecords(
    "p",
    [
      {
        Descrição: "S",
        Orçado: "100",
        Pago: "200",
        Data: "11/11/2026",
        Método: "Pix",
      },
    ],
    {
      description: "Descrição",
      budget: "Orçado",
      paid: "Pago",
      date: "Data",
      method: "Método",
    },
  );
  assert.equal(result.records.length, 1);
  assert.equal(result.warnings.length, 1);
});
