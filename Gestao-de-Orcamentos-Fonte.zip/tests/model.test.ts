import { test } from "node:test";
import assert from "node:assert/strict";
import {
  Ledger,
  defaultProject,
  defaultItem,
  cents,
  budget,
  paid,
  remaining,
  status,
  uuid,
  type Payment,
  type Op,
  validOp,
} from "../src/model";
function fixtures() {
  let ledger = new Ledger(),
    project = defaultProject("Teste"),
    item = {
      ...defaultItem(project.id),
      description: "Serviço",
      supplier: "Fornecedor",
      budgetCents: 10000,
    };
  let op = ledger.create("A", "project", project.id, project);
  ledger.ingest([op]);
  let iop = ledger.create("A", "item", item.id, item);
  ledger.ingest([iop]);
  return { ledger, project, item };
}
test("Valores em centavos e pagamentos parciais", () => {
  assert.equal(cents("R$ 1.250,50"), 125050);
  assert.equal(cents("0,10") + cents("0,20"), 30);
  let { item } = fixtures();
  let payment: Payment = {
    id: uuid(),
    itemId: item.id,
    amountCents: 2500,
    date: "2026-11-11",
    method: "Pix",
    notes: "",
  };
  assert.equal(budget(item), 10000);
  assert.equal(paid(item, [payment]), 2500);
  assert.equal(remaining(item, [payment]), 7500);
  assert.equal(status(item, [payment]), "partial");
});
test("Entrega duplicada não duplica pagamentos", () => {
  let { ledger, item } = fixtures();
  let payment: Payment = {
    id: uuid(),
    itemId: item.id,
    amountCents: 1000,
    date: "2026-11-11",
    method: "Pix",
    notes: "",
  };
  let op = ledger.create("A", "payment", payment.id, payment);
  ledger.ingest([op, op]);
  assert.equal(ledger.snapshot().payments.length, 1);
  assert.equal(paid(item, ledger.snapshot().payments), 1000);
});
test("Alterações concorrentes preservam alternativas e convergem em qualquer ordem", () => {
  let { ledger, item } = fixtures(),
    a = new Ledger(ledger.export()),
    b = new Ledger(ledger.export());
  let oa = a.create("A", "item", item.id, {
      ...item,
      supplier: "Fornecedor A",
    }),
    ob = b.create("B", "item", item.id, { ...item, supplier: "Fornecedor B" });
  a.ingest([oa, ob]);
  b.ingest([ob, oa]);
  assert.equal(a.snapshot().conflicts.length, 1);
  assert.deepEqual(a.snapshot(), b.snapshot());
  let resolve = a.create("A", "item", item.id, {
    ...item,
    supplier: "Escolhido",
  });
  assert.equal(resolve.parents.length, 2);
  a.ingest([resolve]);
  b.ingest([resolve]);
  assert.equal(a.snapshot().conflicts.length, 0);
  assert.deepEqual(a.snapshot(), b.snapshot());
});
test("Pagamento disputado fica fora dos totais até resolução", () => {
  let { ledger, item } = fixtures(),
    p: Payment = {
      id: uuid(),
      itemId: item.id,
      amountCents: 1000,
      date: "2026-11-11",
      method: "Pix",
      notes: "",
    };
  let init = ledger.create("A", "payment", p.id, p);
  ledger.ingest([init]);
  let a = ledger.create("A", "payment", p.id, { ...p, amountCents: 2000 }),
    b = ledger.create("B", "payment", p.id, { ...p, amountCents: 3000 });
  ledger.ingest([a, b]);
  assert.equal(ledger.snapshot().payments.length, 0);
  assert.equal(ledger.snapshot().conflicts.length, 1);
});
test("Exclusão não ressuscita quando um dispositivo entrega eventos antigos", () => {
  let { ledger, item } = fixtures(),
    old = ledger.export();
  let deleted = ledger.create("A", "item", item.id, null);
  ledger.ingest([deleted]);
  ledger.ingest(old);
  assert.equal(ledger.snapshot().items.length, 0);
  let reverse = new Ledger([deleted, ...old]);
  assert.equal(reverse.snapshot().items.length, 0);
});
test("Valores mínimos e validação de dados recebidos", () => {
  let { ledger, item } = fixtures();
  assert.equal(
    status({ ...item, budgetCents: null, unitCents: 0 }, []),
    "planned",
  );
  let invalid = {
    ...ledger.export()[0],
    value: { ...defaultProject("Teste"), color: "javascript:bad" },
  } as Op;
  assert.equal(validOp(invalid), false);
  assert.throws(() => ledger.ingest([invalid]));
  assert.throws(() => cents("-10.111"));
  assert.throws(() => cents("NaN"));
});
test("Comprovante é preservado no histórico e no backup", () => {
  let { ledger, item } = fixtures();
  let payment: Payment = {
    id: uuid(),
    itemId: item.id,
    amountCents: 1000,
    date: "2026-11-11",
    method: "Pix",
    notes: "",
    receipt: {
      name: "recibo.png",
      type: "image/png",
      data: "data:image/png;base64,iVBORw0KGgo=",
    },
  };
  ledger.ingest([ledger.create("A", "payment", payment.id, payment)]);
  let restore = new Ledger(JSON.parse(JSON.stringify(ledger.export())));
  assert.deepEqual(restore.snapshot().payments[0].receipt, payment.receipt);
});
test("Pagamentos concorrentes novos são ambos preservados para revisão de excedente", () => {
  let { ledger, item } = fixtures();
  let p: Payment = {
      id: uuid(),
      itemId: item.id,
      amountCents: 6000,
      date: "2026-11-11",
      method: "Pix",
      notes: "",
    },
    q = { ...p, id: uuid() };
  ledger.ingest([
    ledger.create("A", "payment", p.id, p),
    ledger.create("B", "payment", q.id, q),
  ]);
  assert.equal(remaining(item, ledger.snapshot().payments), -2000);
  assert.equal(ledger.snapshot().payments.length, 2);
});
