import { readdir, readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
const files = [];
async function walk(dir) {
  for (let entry of await readdir(dir, { withFileTypes: true })) {
    let path = dir + "/" + entry.name;
    if (entry.isDirectory()) await walk(path);
    else if (entry.name !== "sw.js" && entry.name !== "version.json")
      files.push(path);
  }
}
await walk("dist");
let hash = createHash("sha256");
for (let file of files.sort()) hash.update(await readFile(file));
let version = hash.digest("hex").slice(0, 16);
let assets = files
  .filter((f) => !f.startsWith("dist/downloads/"))
  .map((f) => "./" + f.slice(5));
let sw = `const VERSION='gorc-${version}';const ASSETS=${JSON.stringify(assets)};const BASE=new URL('./',self.location.href);
self.addEventListener('install',event=>event.waitUntil(caches.open(VERSION).then(cache=>cache.addAll(ASSETS))));
self.addEventListener('message',event=>{if(event.data?.type==='ACTIVATE_UPDATE')self.skipWaiting()});
self.addEventListener('activate',event=>event.waitUntil((async()=>{for(const key of await caches.keys())if(key.startsWith('gorc-')&&key!==VERSION)await caches.delete(key);await self.clients.claim()})()));
self.addEventListener('fetch',event=>{const req=event.request;const url=new URL(req.url);if(req.method!=='GET'||url.origin!==BASE.origin||!url.pathname.startsWith(BASE.pathname))return;if(req.mode==='navigate'){event.respondWith(caches.open(VERSION).then(cache=>cache.match(new URL('index.html',BASE)).then(hit=>hit||fetch(req))));return}if(url.pathname.endsWith('/sw.js')||url.pathname.endsWith('/version.json'))return;event.respondWith(caches.open(VERSION).then(cache=>cache.match(req).then(hit=>hit||fetch(req))))});`;
await writeFile("dist/sw.js", sw);
await writeFile(
  "dist/version.json",
  JSON.stringify({ version: "1.0.0", build: version }),
);
console.log("Offline cache:", files.length, "assets, build", version);
