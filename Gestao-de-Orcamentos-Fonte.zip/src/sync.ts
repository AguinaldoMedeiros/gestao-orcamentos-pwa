import { store, meta, setMeta } from "./database";
import { type Op, uuid } from "./model";
type PairCode = {
  app: "gestao-orcamentos";
  v: 1;
  session: string;
  secret?: string;
  description: RTCSessionDescriptionInit;
};
export type PeerView = {
  id: string;
  label: string;
  state: string;
  approved: boolean;
  remoteApproved: boolean;
  code: string;
  error: string;
};
type Peer = {
  view: PeerView;
  pc: RTCPeerConnection;
  dc?: RTCDataChannel;
  secret: string;
  key?: CryptoKey;
  sendQueue: Promise<void>;
  incoming: Map<
    string,
    { parts: string[]; count: number; total: number; size: number }
  >;
  inputQueue: Promise<void>;
  synced: boolean;
};
const base64 = (bytes: Uint8Array) => {
  let s = "";
  for (let n of bytes) s += String.fromCharCode(n);
  return btoa(s);
};
const bytes = (s: string) => Uint8Array.from(atob(s), (x) => x.charCodeAt(0));
type SyncStore = Pick<typeof store, "onOps" | "ledger" | "accept">;
export class PeerSync {
  peers = new Map<string, Peer>();
  listeners = new Set<() => void>();
  version = 0;
  enabled = false;
  constructor(private storage: SyncStore = store) {
    this.storage.onOps.add((ops) => {
      for (let p of this.peers.values())
        if (this.authorized(p)) this.enqueue(p, ops);
    });
  }
  subscribe = (fn: () => void) => {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  };
  getVersion = () => this.version;
  changed() {
    this.version++;
    this.listeners.forEach((f) => f());
  }
  authorized(p: Peer) {
    return (
      p.view.approved && p.view.remoteApproved && p.dc?.readyState === "open"
    );
  }
  async createPeer(session: string, secret: string, label: string) {
    if (!("RTCPeerConnection" in window))
      throw Error("Este navegador não suporta sincronização WebRTC.");
    if (this.peers.size >= 8)
      throw Error("Limite de oito conexões simultâneas.");
    let iceServers = await meta<RTCIceServer[]>("iceServers", []);
    let pc = new RTCPeerConnection({ iceServers });
    let p: Peer = {
      view: {
        id: session,
        label,
        state: "Preparando",
        approved: false,
        remoteApproved: false,
        code: "",
        error: "",
      },
      pc,
      secret,
      sendQueue: Promise.resolve(),
      incoming: new Map(),
      inputQueue: Promise.resolve(),
      synced: false,
    };
    let digest = new Uint8Array(
      await crypto.subtle.digest("SHA-256", bytes(secret)),
    );
    p.view.code = [...digest.slice(0, 4)]
      .map((x) => x.toString(16).padStart(2, "0"))
      .join(" ")
      .toUpperCase();
    p.key = await crypto.subtle.importKey(
      "raw",
      bytes(secret),
      "AES-GCM",
      false,
      ["encrypt", "decrypt"],
    );
    pc.onconnectionstatechange = () => {
      p.view.state = (
        {
          new: "Preparando",
          connecting: "Conectando",
          connected: "Conectado",
          disconnected: "Desconectado",
          failed: "Falha de rede",
          closed: "Encerrado",
        } as Record<string, string>
      )[pc.connectionState];
      this.changed();
    };
    pc.ondatachannel = (e) => this.attach(p, e.channel);
    this.peers.set(session, p);
    this.enabled = true;
    this.changed();
    return p;
  }
  attach(p: Peer, dc: RTCDataChannel) {
    if (dc.label !== "orcamentos-v1") {
      dc.close();
      return;
    }
    p.dc = dc;
    dc.bufferedAmountLowThreshold = 128 * 1024;
    dc.onopen = () => {
      p.view.state = "Aguardando confirmação";
      this.changed();
      if (p.view.approved) dc.send(JSON.stringify({ t: "approve" }));
    };
    dc.onmessage = (e) => {
      p.inputQueue = p.inputQueue
        .then(() => this.receive(p, e.data))
        .catch((err) => {
          p.view.error = String(err.message || err);
          this.changed();
        });
    };
    dc.onclose = () => {
      p.view.state = "Desconectado";
      this.changed();
    };
    dc.onerror = () => {
      p.view.error = "Falha no canal de sincronização.";
      this.changed();
    };
  }
  async gather(p: Peer) {
    await new Promise<void>((resolve, reject) => {
      if (p.pc.iceGatheringState === "complete") {
        resolve();
        return;
      }
      let timer = setTimeout(() => {
        p.pc.removeEventListener("icegatheringstatechange", check);
        reject(
          Error("A rede demorou para preparar a conexão. Tente novamente."),
        );
      }, 15000);
      let check = () => {
        if (p.pc.iceGatheringState === "complete") {
          clearTimeout(timer);
          p.pc.removeEventListener("icegatheringstatechange", check);
          resolve();
        }
      };
      p.pc.addEventListener("icegatheringstatechange", check);
    });
    if (!p.pc.localDescription)
      throw Error("Não foi possível criar o convite.");
  }
  encode(code: PairCode) {
    return base64(new TextEncoder().encode(JSON.stringify(code)));
  }
  decode(raw: string): PairCode {
    if (raw.length > 150000) throw Error("Código muito grande.");
    let code: PairCode;
    try {
      code = JSON.parse(new TextDecoder().decode(bytes(raw.trim())));
    } catch {
      throw Error("Código de pareamento inválido.");
    }
    if (
      code.app !== "gestao-orcamentos" ||
      code.v !== 1 ||
      !code.session ||
      !code.description ||
      !["offer", "answer"].includes(code.description.type) ||
      typeof code.description.sdp !== "string"
    )
      throw Error("Código incompatível.");
    return code;
  }
  async invite() {
    let secret = base64(crypto.getRandomValues(new Uint8Array(32))),
      id = uuid(),
      p = await this.createPeer(id, secret, "Computador convidado");
    try {
      this.attach(
        p,
        p.pc.createDataChannel("orcamentos-v1", { ordered: true }),
      );
      await p.pc.setLocalDescription(await p.pc.createOffer());
      await this.gather(p);
      return {
        id,
        code: this.encode({
          app: "gestao-orcamentos",
          v: 1,
          session: id,
          secret,
          description: p.pc.localDescription!.toJSON(),
        }),
      };
    } catch (e) {
      this.disconnect(id);
      throw e;
    }
  }
  async accept(raw: string) {
    let code = this.decode(raw);
    if (
      code.description.type !== "offer" ||
      !code.secret ||
      bytes(code.secret).length !== 32 ||
      this.peers.has(code.session)
    )
      throw Error("O convite é inválido ou já está conectado.");
    let p = await this.createPeer(
      code.session,
      code.secret,
      "Computador que convidou",
    );
    try {
      await p.pc.setRemoteDescription(code.description);
      await p.pc.setLocalDescription(await p.pc.createAnswer());
      await this.gather(p);
      return {
        id: code.session,
        code: this.encode({
          app: "gestao-orcamentos",
          v: 1,
          session: code.session,
          description: p.pc.localDescription!.toJSON(),
        }),
      };
    } catch (e) {
      this.disconnect(code.session);
      throw e;
    }
  }
  async complete(raw: string) {
    let code = this.decode(raw),
      p = this.peers.get(code.session);
    if (
      code.description.type !== "answer" ||
      !p ||
      p.pc.signalingState !== "have-local-offer"
    )
      throw Error("A resposta não corresponde ao convite pendente.");
    await p.pc.setRemoteDescription(code.description);
    this.changed();
  }
  approve(id: string) {
    let p = this.peers.get(id);
    if (!p) return;
    p.view.approved = true;
    if (p.dc?.readyState === "open")
      p.dc.send(JSON.stringify({ t: "approve" }));
    if (this.authorized(p)) this.start(p);
    this.changed();
  }
  start(p: Peer) {
    if (p.synced) return;
    p.synced = true;
    p.view.state = this.storage.ledger.ops.size
      ? "Sincronizando"
      : "Sincronizado";
    this.enqueue(p, this.storage.ledger.export());
  }
  async receive(p: Peer, data: unknown) {
    if (typeof data !== "string" || data.length > 24000)
      throw Error("Mensagem de sincronização inválida.");
    let frame = JSON.parse(data);
    if (frame.t === "approve") {
      p.view.remoteApproved = true;
      if (this.authorized(p)) this.start(p);
      this.changed();
      return;
    }
    if (!this.authorized(p)) throw Error("Conexão ainda não autorizada.");
    if (
      frame.t !== "chunk" ||
      typeof frame.id !== "string" ||
      !Number.isInteger(frame.n) ||
      !Number.isInteger(frame.total) ||
      frame.total < 1 ||
      frame.total > 6000 ||
      frame.n < 0 ||
      frame.n >= frame.total ||
      typeof frame.data !== "string" ||
      frame.data.length > 14000
    )
      throw Error("Pacote de sincronização inválido.");
    let packet = p.incoming.get(frame.id);
    if (!packet) {
      if (p.incoming.size >= 2)
        throw Error("Muitas transferências simultâneas.");
      packet = {
        parts: new Array(frame.total),
        count: 0,
        total: frame.total,
        size: 0,
      };
      p.incoming.set(frame.id, packet);
    }
    if (packet.total !== frame.total)
      throw Error("Transferência inconsistente.");
    if (packet.parts[frame.n] !== undefined) return;
    packet.parts[frame.n] = frame.data;
    packet.count++;
    packet.size += frame.data.length;
    if (packet.size > 64 * 1024 * 1024) {
      p.incoming.delete(frame.id);
      throw Error("Transferência acima de 64 MB.");
    }
    if (packet.count !== packet.total) return;
    p.incoming.delete(frame.id);
    let encrypted = JSON.parse(packet.parts.join(""));
    let iv = bytes(encrypted.iv),
      cipher = bytes(encrypted.data);
    let plain = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      p.key!,
      cipher,
    );
    let message = JSON.parse(new TextDecoder().decode(plain));
    if (
      message.v !== 1 ||
      !Array.isArray(message.ops) ||
      message.ops.length > 100000
    )
      throw Error("Dados de sincronização incompatíveis.");
    await this.storage.accept(message.ops);
    p.view.state = "Sincronizado";
    p.view.error = "";
    this.changed();
  }
  enqueue(p: Peer, ops: Op[]) {
    if (!ops.length) return;
    p.sendQueue = p.sendQueue
      .then(() => this.send(p, ops))
      .catch((err) => {
        p.view.error = String(err.message || err);
        this.changed();
      });
  }
  async send(p: Peer, ops: Op[]) {
    if (!this.authorized(p)) return;
    let plain = new TextEncoder().encode(JSON.stringify({ v: 1, ops }));
    if (plain.length > 45 * 1024 * 1024)
      throw Error(
        "Histórico acima do limite de 45 MB por transferência. Use backup para a carga inicial.",
      );
    let iv = crypto.getRandomValues(new Uint8Array(12));
    let encrypted = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv },
      p.key!,
      plain,
    );
    let message = JSON.stringify({
        iv: base64(iv),
        data: base64(new Uint8Array(encrypted)),
      }),
      id = uuid(),
      total = Math.ceil(message.length / 12000);
    for (let n = 0; n < total; n++) {
      if (!this.authorized(p))
        throw Error(
          "Dispositivo desconectado. Refazer o pareamento enviará as alterações pendentes.",
        );
      if (p.dc!.bufferedAmount > 512 * 1024)
        await new Promise<void>((resolve, reject) => {
          let timeout = setTimeout(() => {
            cleanup();
            reject(Error("A conexão está lenta. Tente parear novamente."));
          }, 15000);
          let cleanup = () => {
            clearTimeout(timeout);
            p.dc!.removeEventListener("bufferedamountlow", done);
            p.dc!.removeEventListener("close", closed);
          };
          let done = () => {
              cleanup();
              resolve();
            },
            closed = () => {
              cleanup();
              reject(Error("Conexão encerrada."));
            };
          p.dc!.addEventListener("bufferedamountlow", done, { once: true });
          p.dc!.addEventListener("close", closed, { once: true });
        });
      p.dc!.send(
        JSON.stringify({
          t: "chunk",
          id,
          n,
          total,
          data: message.slice(n * 12000, (n + 1) * 12000),
        }),
      );
    }
    p.view.state = "Sincronizado";
    this.changed();
  }
  disconnect(id: string) {
    let p = this.peers.get(id);
    if (!p) return;
    p.dc?.close();
    p.pc.close();
    this.peers.delete(id);
    this.enabled = this.peers.size > 0;
    this.changed();
  }
  disconnectAll() {
    for (let id of [...this.peers.keys()]) this.disconnect(id);
  }
  async configureNetwork(url: string, user: string, password: string) {
    let servers: RTCIceServer[] = [];
    if (url.trim()) {
      if (!/^(stun|stuns|turn|turns):[^\s]+$/.test(url.trim()))
        throw Error("Informe um endereço STUN/TURN válido.");
      servers = [
        {
          urls: url.trim(),
          ...(user ? { username: user, credential: password } : {}),
        },
      ];
    }
    await setMeta("iceServers", servers);
  }
}
export const sync = new PeerSync();
