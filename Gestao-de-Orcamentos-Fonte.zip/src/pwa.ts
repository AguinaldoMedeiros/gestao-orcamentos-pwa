declare global {
 interface Window {desktopApp?: {info:()=>Promise<{version:string;dataDirectory:string;origin:string;smokeMode:boolean}>;ready:(result:{storage:boolean;ui:boolean;previous:boolean})=>Promise<boolean>;checkUpdate:()=>Promise<{available:boolean;version?:string;message:string}>;openRelease:()=>Promise<void>}}
}
export const desktopMode = !!window.desktopApp;
export type InstallEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: string }>;
};
let promptEvent: InstallEvent | null = null,
  registration: ServiceWorkerRegistration | undefined;
let listeners = new Set<() => void>();
let ready = false;
export const pwaState = {
  installable: false,
  installed: desktopMode || window.matchMedia("(display-mode: standalone)").matches,
  update: false,
  status: "",
};
export const subscribePwa = (fn: () => void) => {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
};
let version = 0;
export const pwaVersion = () => version;
const emit = () => {
  version++;
  listeners.forEach((fn) => fn());
};
window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  promptEvent = e as InstallEvent;
  pwaState.installable = true;
  emit();
});
window.addEventListener("appinstalled", () => {
  pwaState.installed = true;
  pwaState.installable = false;
  emit();
});
export async function install() {
  if(desktopMode) return;
  if (promptEvent) {
    await promptEvent.prompt();
    let result = await promptEvent.userChoice;
    if (result.outcome === "accepted") {
      promptEvent = null;
      pwaState.installable = false;
      emit();
    }
  } else
    throw Error(
      "No Edge/Chrome, use o menu do navegador > Aplicativos > Instalar este site. No iPhone, use Compartilhar > Adicionar à Tela de Início e marque Abrir como App.",
    );
}
export async function initializePwa() {
  if(window.desktopApp){
    const info=await window.desktopApp.info();
    if(info.smokeMode){
      const open=()=>new Promise<IDBDatabase>((resolve,reject)=>{const r=indexedDB.open("gorc-startup-check",1);r.onupgradeneeded=()=>r.result.createObjectStore("checks");r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
      let db=await open();
      const previous=await new Promise<unknown>((resolve,reject)=>{const r=db.transaction("checks").objectStore("checks").get("marker");r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
      await new Promise<void>((resolve,reject)=>{const tx=db.transaction("checks","readwrite");tx.objectStore("checks").put("persistido","marker");tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);});db.close();
      db=await open();const value=await new Promise<unknown>((resolve,reject)=>{const r=db.transaction("checks").objectStore("checks").get("marker");r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});db.close();
      await window.desktopApp.ready({storage:value==="persistido",ui:!!document.querySelector("#content"),previous:previous==="persistido"});
    }
    pwaState.status="Aplicativo completo instalado. Funciona offline sem servidor HTTP."; emit(); return; }
  if (ready || !("serviceWorker" in navigator) || !import.meta.env.PROD) return;
  ready = true;
  try {
    registration = await navigator.serviceWorker.register(
      new URL("sw.js", document.baseURI),
      { scope: "./", updateViaCache: "none" },
    );
    let check = () => {
      pwaState.update = !!registration?.waiting;
      emit();
    };
    registration.addEventListener("updatefound", () => {
      let installing = registration?.installing;
      installing?.addEventListener("statechange", () => {
        if (installing.state === "installed") check();
      });
    });
    check();
    let reloading = false;
    navigator.serviceWorker.addEventListener("controllerchange", () => {
      if (!reloading) {
        reloading = true;
        location.reload();
      }
    });
  } catch (e) {
    pwaState.status =
      "Não foi possível preparar o funcionamento offline: " + String(e);
    emit();
  }
}
export async function checkUpdate() {
  if(window.desktopApp){pwaState.status="Consultando novas versões no GitHub…";emit();const result=await window.desktopApp.checkUpdate();pwaState.update=result.available;pwaState.status=result.message;emit();return;}
  if (!registration) {
    pwaState.status = import.meta.env.DEV
      ? "Atualizações são ativadas na versão publicada."
      : "O cache local ainda não foi preparado. Reabra o aplicativo.";
    emit();
    return;
  }
  pwaState.status = "Verificando atualização publicada…";
  emit();
  try {
    await registration.update();
    pwaState.update = !!registration.waiting;
    pwaState.status = pwaState.update
      ? "Uma nova versão está pronta."
      : "Consulta concluída. Se houver nova versão, ela aparecerá assim que o download terminar.";
    emit();
  } catch {
    pwaState.status =
      "Sem conexão para verificar. O aplicativo continua disponível offline.";
    emit();
  }
}
export function applyUpdate() {
  if(window.desktopApp){void window.desktopApp.openRelease();return;}
  registration?.waiting?.postMessage({ type: "ACTIVATE_UPDATE" });
}
