export type InstallEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: string }>;
};
let promptEvent: InstallEvent | null = null,
  registration: ServiceWorkerRegistration | undefined;
let listeners = new Set<() => void>();
let ready = false;
export const pwaState = {
  installable: false,
  installed: window.matchMedia("(display-mode: standalone)").matches,
  update: false,
  status: "",
};
export const subscribePwa = (fn: () => void) => {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
};
let version = 0;
export const pwaVersion = () => version;
const emit = () => {
  version++;
  listeners.forEach((fn) => fn());
};
window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  promptEvent = e as InstallEvent;
  pwaState.installable = true;
  emit();
});
window.addEventListener("appinstalled", () => {
  pwaState.installed = true;
  pwaState.installable = false;
  emit();
});
export async function install() {
  if (promptEvent) {
    await promptEvent.prompt();
    let result = await promptEvent.userChoice;
    if (result.outcome === "accepted") {
      promptEvent = null;
      pwaState.installable = false;
      emit();
    }
  } else
    throw Error(
      "No Edge/Chrome, use o menu do navegador > Aplicativos > Instalar este site. No iPhone, use Compartilhar > Adicionar à Tela de Início e marque Abrir como App.",
    );
}
export async function initializePwa() {
  if (ready || !("serviceWorker" in navigator) || !import.meta.env.PROD) return;
  ready = true;
  try {
    registration = await navigator.serviceWorker.register(
      new URL("sw.js", document.baseURI),
      { scope: "./", updateViaCache: "none" },
    );
    let check = () => {
      pwaState.update = !!registration?.waiting;
      emit();
    };
    registration.addEventListener("updatefound", () => {
      let installing = registration?.installing;
      installing?.addEventListener("statechange", () => {
        if (installing.state === "installed") check();
      });
    });
    check();
    let reloading = false;
    navigator.serviceWorker.addEventListener("controllerchange", () => {
      if (!reloading) {
        reloading = true;
        location.reload();
      }
    });
  } catch (e) {
    pwaState.status =
      "Não foi possível preparar o funcionamento offline: " + String(e);
    emit();
  }
}
export async function checkUpdate() {
  if (!registration) {
    pwaState.status = import.meta.env.DEV
      ? "Atualizações são ativadas na versão publicada."
      : "O cache local ainda não foi preparado. Reabra o aplicativo.";
    emit();
    return;
  }
  pwaState.status = "Verificando atualização publicada…";
  emit();
  try {
    await registration.update();
    pwaState.update = !!registration.waiting;
    pwaState.status = pwaState.update
      ? "Uma nova versão está pronta."
      : "Consulta concluída. Se houver nova versão, ela aparecerá assim que o download terminar.";
    emit();
  } catch {
    pwaState.status =
      "Sem conexão para verificar. O aplicativo continua disponível offline.";
    emit();
  }
}
export function applyUpdate() {
  registration?.waiting?.postMessage({ type: "ACTIVATE_UPDATE" });
}
