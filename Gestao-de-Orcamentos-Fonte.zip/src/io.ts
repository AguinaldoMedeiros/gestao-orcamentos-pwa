import { store } from "./database";
import {
  type Item,
  type Project,
  type Payment,
  defaultItem,
  defaultProject,
  uuid,
  cents,
  budget,
  paid,
  remaining,
  brDate,
  statusNames,
  status,
  Ledger,
  type Op,
} from "./model";
export function download(
  name: string,
  data: BlobPart,
  type = "application/json",
) {
  let url = URL.createObjectURL(new Blob([data], { type })),
    a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
export const backup = () =>
  download(
    "gestao-orcamentos-" +
      new Date().toISOString().replace(/[:.]/g, "-") +
      ".gorc",
    JSON.stringify(
      {
        app: "gestao-orcamentos",
        version: 1,
        operations: store.ledger.export(),
      },
      null,
      2,
    ),
  );
export async function importBackup(file: File, replace: boolean) {
  if (file.size > 64 * 1024 * 1024) throw Error("Backup acima de 64 MB.");
  let data = JSON.parse(await file.text());
  if (
    data.app !== "gestao-orcamentos" ||
    data.version !== 1 ||
    !Array.isArray(data.operations)
  )
    throw Error("Backup incompatível. Use um arquivo .gorc.");
  let ledger = new Ledger(data.operations as Op[]);
  if (!replace) {
    await store.accept(ledger.export());
    return;
  }
  if (ledger.snapshot().conflicts.length)
    throw Error(
      "O backup contém conflitos. Importe como mesclagem para resolvê-los antes.",
    );
  let target = ledger.snapshot();
  await store.accept(ledger.export());
  let current = store.snapshot;
  let records: {
    entity: "project" | "item" | "payment";
    key: string;
    value: Project | Item | Payment | null;
  }[] = [];
  for (let [entity, values, desired] of [
    ["project", current.projects, target.projects],
    ["item", current.items, target.items],
    ["payment", current.payments, target.payments],
  ] as const) {
    let ids = new Set(desired.map((x) => x.id));
    for (let v of values)
      if (!ids.has(v.id)) records.push({ entity, key: v.id, value: null });
    for (let v of desired) records.push({ entity, key: v.id, value: v });
  }
  await store.batch(records);
}
export async function readReceipt(file: File) {
  if (file.size > 5 * 1024 * 1024)
    throw Error("Use um comprovante de até 5 MB.");
  if (
    ![
      "image/png",
      "image/jpeg",
      "image/webp",
      "image/gif",
      "application/pdf",
    ].includes(file.type)
  )
    throw Error("Use imagem PNG, JPG, WEBP, GIF ou PDF.");
  let data = await new Promise<string>((resolve, reject) => {
    let r = new FileReader();
    r.onload = () => resolve(String(r.result));
    r.onerror = () => reject(Error("Falha ao ler o arquivo."));
    r.readAsDataURL(file);
  });
  return { name: file.name, type: file.type, data };
}
export function receiptURL(p: Payment) {
  if (!p.receipt) return "";
  let r = p.receipt,
    bin = atob(r.data.slice(r.data.indexOf(",") + 1)),
    bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
  return URL.createObjectURL(new Blob([bytes], { type: r.type }));
}
export async function exportXlsx(
  p: Project,
  items: Item[],
  payments: Payment[],
) {
  let { default: ExcelJS } = await import("exceljs");
  let wb = new ExcelJS.Workbook();
  let sheet = wb.addWorksheet("Orçamento");
  let headers = [
    "Descrição",
    "Categoria",
    "Fornecedor",
    "Quantidade",
    "Valor Unitário",
    "Valor Orçado",
    "Valor Já Pago",
    "Restante a Pagar",
    "Status",
    "Vencimento",
    ...p.columns.map((c) => c.name),
  ];
  sheet.addRow(headers);
  for (let i of items)
    sheet.addRow([
      i.description,
      i.category,
      i.supplier,
      i.quantity,
      i.unitCents / 100,
      budget(i) / 100,
      paid(i, payments) / 100,
      remaining(i, payments) / 100,
      statusNames[status(i, payments)],
      brDate(i.due),
      ...p.columns.map((c) => i.custom[c.id] || ""),
    ]);
  sheet.getRow(1).font = { bold: true };
  sheet.columns.forEach((c) => (c.width = 22));
  for (let col of [5, 6, 7, 8]) sheet.getColumn(col).numFmt = '"R$" #,##0.00';
  sheet.views = [{ state: "frozen", ySplit: 1 }];
  let paySheet = wb.addWorksheet("Pagamentos");
  paySheet.addRow(["Item", "Valor", "Data", "Método", "Observações"]);
  for (let pay of payments.filter((pay) =>
    items.some((i) => i.id === pay.itemId),
  ))
    paySheet.addRow([
      items.find((i) => i.id === pay.itemId)?.description,
      pay.amountCents / 100,
      brDate(pay.date),
      pay.method,
      pay.notes,
    ]);
  paySheet.columns.forEach((c) => (c.width = 24));
  paySheet.getRow(1).font = { bold: true };
  download(
    p.name.replace(/[^\p{L}\p{N}_-]/gu, "_") + ".xlsx",
    await wb.xlsx.writeBuffer(),
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  );
}
export async function exportPdf(
  p: Project,
  items: Item[],
  payments: Payment[],
) {
  let { jsPDF } = await import("jspdf"),
    pdf = new jsPDF();
  let y = 20;
  pdf.setFontSize(18);
  pdf.text(p.name.slice(0, 70), 15, y);
  y += 10;
  pdf.setFontSize(10);
  pdf.text("Orçamento | " + new Date().toLocaleDateString("pt-BR"), 15, y);
  y += 12;
  let total = 0,
    settled = 0;
  for (let i of items) {
    if (y > 265) {
      pdf.addPage();
      y = 20;
    }
    pdf.setFont("helvetica", "bold");
    pdf.text(i.description.slice(0, 90), 15, y);
    y += 6;
    pdf.setFont("helvetica", "normal");
    pdf.text(
      (i.supplier + " | " + statusNames[status(i, payments)]).slice(0, 100),
      15,
      y,
    );
    y += 6;
    let line =
      "Orçado: R$ " +
      (budget(i) / 100).toFixed(2) +
      "   Pago: R$ " +
      (paid(i, payments) / 100).toFixed(2) +
      "   Saldo: R$ " +
      (remaining(i, payments) / 100).toFixed(2);
    pdf.text(line, 15, y);
    y += 11;
    if (i.status !== "cancelled") {
      total += budget(i);
      settled += paid(i, payments);
    }
  }
  if (y > 260) {
    pdf.addPage();
    y = 20;
  }
  pdf.setFont("helvetica", "bold");
  pdf.text(
    "Totais ativos: orçado R$ " +
      (total / 100).toFixed(2) +
      " | pago R$ " +
      (settled / 100).toFixed(2) +
      " | saldo R$ " +
      ((total - settled) / 100).toFixed(2),
    15,
    y + 5,
  );
  download(
    "relatorio-orcamento.pdf",
    pdf.output("arraybuffer"),
    "application/pdf",
  );
}
export type MappingField =
  | "description"
  | "supplier"
  | "category"
  | "quantity"
  | "unit"
  | "budget"
  | "paid"
  | "date"
  | "method"
  | "due"
  | "status";
export const mappingLabels: Record<MappingField, string> = {
  description: "Descrição",
  supplier: "Fornecedor",
  category: "Categoria",
  quantity: "Quantidade",
  unit: "Valor Unitário",
  budget: "Valor Orçado",
  paid: "Valor Já Pago",
  date: "Data do pagamento",
  method: "Pagamento / método",
  due: "Vencimento",
  status: "Status",
};
export function csvRows(text: string) {
  text = text.replace(/^\uFEFF/, "");
  let first = text.split(/\r?\n/)[0] || "",
    delimiter =
      (first.match(/;/g) || []).length > (first.match(/,/g) || []).length
        ? ";"
        : ",",
    rows: string[][] = [],
    row: string[] = [],
    value = "",
    quoted = false;
  for (let n = 0; n < text.length; n++) {
    let c = text[n];
    if (c === '"') {
      if (quoted && text[n + 1] === '"') {
        value += '"';
        n++;
      } else quoted = !quoted;
    } else if (c === delimiter && !quoted) {
      row.push(value);
      value = "";
    } else if ((c === "\n" || c === "\r") && !quoted) {
      if (c === "\r" && text[n + 1] === "\n") n++;
      row.push(value);
      if (row.some(Boolean)) rows.push(row);
      row = [];
      value = "";
    } else value += c;
  }
  if (quoted) throw Error("CSV com aspas não fechadas.");
  row.push(value);
  if (row.some(Boolean)) rows.push(row);
  let headers = rows.shift() || [];
  if (new Set(headers).size !== headers.length)
    throw Error(
      "O arquivo tem nomes de colunas repetidos. Renomeie antes de importar.",
    );
  return rows.map((r) =>
    Object.fromEntries(headers.map((h, n) => [h, r[n] || ""])),
  );
}
export async function spreadsheetRows(file: File) {
  if (file.size > 15 * 1024 * 1024) throw Error("Planilha acima de 15 MB.");
  if (file.name.toLowerCase().endsWith(".csv"))
    return csvRows(await file.text());
  let { default: ExcelJS } = await import("exceljs"),
    wb = new ExcelJS.Workbook();
  await wb.xlsx.load(await file.arrayBuffer());
  let sheet = wb.worksheets[0];
  if (!sheet) return [];
  let headers: string[] = [],
    rows: Record<string, unknown>[] = [];
  sheet.getRow(1).eachCell({ includeEmpty: true }, (cell, n) => {
    headers[n - 1] = cell.text || "Coluna " + n;
  });
  if (new Set(headers).size !== headers.length)
    throw Error("A planilha tem nomes de colunas repetidos.");
  sheet.eachRow((row, n) => {
    if (n === 1) return;
    let out: Record<string, unknown> = {};
    headers.forEach((h, k) => {
      let cell = row.getCell(k + 1),
        v = cell.value;
      if (v instanceof Date) out[h] = v.toISOString().slice(0, 10);
      else if (v && typeof v === "object" && "result" in v) out[h] = v.result;
      else
        out[h] = typeof v === "number" || typeof v === "string" ? v : cell.text;
    });
    rows.push(out);
  });
  return rows;
}
function parsedDate(v: unknown) {
  if (v === undefined || v === null || v === "") return "";
  if (typeof v === "number") {
    let day = new Date(Date.UTC(1899, 11, 30) + Math.round(v) * 86400000);
    return day.toISOString().slice(0, 10);
  }
  let s = String(v).trim(),
    m = s.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  return m ? `${m[3]}-${m[2]}-${m[1]}` : s.slice(0, 10);
}
export function mappedRecords(
  projectId: string,
  rows: Record<string, unknown>[],
  mapping: Partial<Record<MappingField, string>>,
) {
  let records: {
      entity: "item" | "payment";
      key: string;
      value: Item | Payment;
    }[] = [],
    warnings: string[] = [];
  rows.forEach((row, n) => {
    let get = (k: MappingField) => (mapping[k] ? row[mapping[k]!] : "");
    if (!String(get("description") || "").trim()) {
      warnings.push(`Linha ${n + 2}: sem descrição; ignorada.`);
      return;
    }
    let item = defaultItem(projectId);
    item.description = String(get("description")).trim();
    item.supplier = String(get("supplier") || "").trim();
    item.category = String(get("category") || "").trim();
    item.quantity =
      get("quantity") === ""
        ? 1
        : Number(String(get("quantity")).replace(",", "."));
    item.unitCents = cents(String(get("unit") || 0));
    item.budgetCents =
      get("budget") === "" ? null : cents(String(get("budget")));
    item.due = parsedDate(get("due"));
    let st = String(get("status")).toLowerCase();
    item.status = st.includes("cancel")
      ? "cancelled"
      : st.includes("confirm")
        ? "confirmed"
        : st.includes("cota")
          ? "quoted"
          : "planned";
    records.push({ entity: "item", key: item.id, value: item });
    let amount = cents(String(get("paid") || 0));
    if (amount > 0) {
      let date = parsedDate(get("date")),
        method = String(get("method") || "").trim();
      if (!date || !method) {
        warnings.push(
          `Linha ${n + 2}: valor já pago não importado; faltam data e/ou método.`,
        );
        return;
      }
      if (amount > budget(item)) {
        warnings.push(
          `Linha ${n + 2}: pagamento superior ao orçamento não importado. Registre com confirmação.`,
        );
        return;
      }
      let payment: Payment = {
        id: uuid(),
        itemId: item.id,
        amountCents: amount,
        date,
        method,
        notes: "Pagamento inicial importado",
      };
      records.push({ entity: "payment", key: payment.id, value: payment });
    }
  });
  return { records, warnings };
}
export async function importLegacy(file: File) {
  let data = JSON.parse(await file.text());
  if (data.app !== "camaleao-prototype" || !Array.isArray(data.projects))
    throw Error("Arquivo de protótipo inválido.");
  let records: {
    entity: "project" | "item" | "payment";
    key: string;
    value: Project | Item | Payment;
  }[] = [];
  for (let old of data.projects) {
    let p = defaultProject(String(old.name));
    p.id = "legacy-project-" + String(old.id);
    p.description = String(old.description || "");
    p.color = /^#[0-9a-f]{6}$/i.test(old.color) ? old.color : "#0969cf";
    p.view = old.view === "cards" ? "cards" : "table";
    p.type =
      old.type === "Evento"
        ? "event"
        : old.type === "Orçamento"
          ? "budget"
          : "blank";
    p.columns = (old.customColumns || []).map(
      (c: { id: string; name: string; type: string }) => ({
        id: c.id,
        name: c.name,
        type: c.type,
      }),
    );
    records.push({ entity: "project", key: p.id, value: p });
    for (let oi of old.items || []) {
      let item = defaultItem(p.id);
      item.id = "legacy-item-" + String(oi.id);
      Object.assign(item, {
        description: String(oi.name),
        supplier: String(oi.supplier || ""),
        category: String(oi.cat || ""),
        quantity: Number(oi.quantity) || 1,
        unitCents: cents(Number(oi.unit) || 0),
        budgetCents: oi.budget == null ? null : cents(Number(oi.budget)),
        due: oi.due || "",
        status: oi.status || "planned",
        notes: oi.notes || "",
        custom: oi.customValues || {},
      });
      records.push({ entity: "item", key: item.id, value: item });
      for (let op of oi.payments || []) {
        let payment: Payment = {
          id: "legacy-payment-" + String(op.id),
          itemId: item.id,
          amountCents: cents(Number(op.amount)),
          date: op.date,
          method: op.method,
          notes: op.notes || "",
        };
        if (op.receiptData)
          payment.receipt = {
            name: op.receipt || "comprovante",
            type: op.receiptMime || op.receiptData.split(";")[0].slice(5),
            data: op.receiptData,
          };
        records.push({ entity: "payment", key: payment.id, value: payment });
      }
    }
  }
  await store.batch(records);
}
