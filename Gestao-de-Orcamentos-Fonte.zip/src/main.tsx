import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import { store } from "./database";
import "./styles.css";
const root = createRoot(document.getElementById("root")!);
root.render(
  <div style={{ padding: 40, fontFamily: "Segoe UI, sans-serif" }}>
    Abrindo banco local…
  </div>,
);
store
  .init()
  .then(() => root.render(<App />))
  .catch((error) =>
    root.render(
      <div style={{ padding: 40, fontFamily: "Segoe UI, sans-serif" }}>
        <h1>Não foi possível abrir o banco local</h1>
        <p>{String(error.message)}</p>
        <p>
          Verifique se o navegador permite IndexedDB e se há espaço no
          dispositivo. Seus dados existentes não foram apagados.
        </p>
        <button onClick={() => location.reload()}>Tentar novamente</button>
      </div>,
    ),
  );
