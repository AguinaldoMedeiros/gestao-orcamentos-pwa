export type Entity = "project" | "item" | "payment";
export type BaseStatus = "planned" | "quoted" | "confirmed" | "cancelled";
export type Project = {
  id: string;
  name: string;
  description: string;
  type: "blank" | "budget" | "event";
  color: string;
  view: "table" | "cards";
  columns: Column[];
};
export type Column = {
  id: string;
  name: string;
  type: "text" | "number" | "date" | "choice";
};
export type Item = {
  id: string;
  projectId: string;
  description: string;
  supplier: string;
  category: string;
  quantity: number;
  unitCents: number;
  budgetCents: number | null;
  due: string;
  status: BaseStatus;
  notes: string;
  custom: Record<string, string>;
};
export type Payment = {
  id: string;
  itemId: string;
  amountCents: number;
  date: string;
  method: string;
  notes: string;
  receipt?: { name: string; type: string; data: string };
};
export type RecordValue = Project | Item | Payment;
export type Op = {
  id: string;
  actor: string;
  clock: number;
  entity: Entity;
  key: string;
  parents: string[];
  value: RecordValue | null;
  time: string;
};
export type Conflict = { entity: Entity; key: string; heads: Op[] };
export type Snapshot = {
  projects: Project[];
  items: Item[];
  payments: Payment[];
  conflicts: Conflict[];
};
export const uuid = () => crypto.randomUUID();
export function cents(value: string | number): number {
  if (typeof value === "number") {
    if (!Number.isFinite(value) || Math.abs(value) > 1e10)
      throw Error("Valor inválido");
    return Math.round(value * 100);
  }
  let s = value.trim().replace(/R\$|\s/g, "");
  if (!s) return 0;
  if (s.includes(",")) s = s.replace(/\./g, "").replace(",", ".");
  if (!/^-?\d+(\.\d{1,2})?$/.test(s))
    throw Error("Use um valor como 1.250,50.");
  let n = Math.round(Number(s) * 100);
  if (!Number.isSafeInteger(n) || Math.abs(n) > 1e12)
    throw Error("Valor fora do limite.");
  return n;
}
export const money = (v: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(
    v / 100,
  );
export const today = () => new Date().toLocaleDateString("sv-SE");
export const brDate = (v: string) =>
  v
    ? /^\d{4}-\d{2}-\d{2}$/.test(v)
      ? v.split("-").reverse().join("/")
      : v
    : "Sem vencimento";
export function validDate(s: string) {
  if (!s) return true;
  let d = new Date(s + "T12:00:00Z");
  return (
    /^\d{4}-\d{2}-\d{2}$/.test(s) &&
    Number.isFinite(+d) &&
    d.toISOString().slice(0, 10) === s
  );
}
export const budget = (i: Item) =>
  i.budgetCents ?? Math.round(i.quantity * i.unitCents);
export const paid = (i: Item, p: Payment[]) =>
  p.filter((x) => x.itemId === i.id).reduce((n, x) => n + x.amountCents, 0);
export const remaining = (i: Item, p: Payment[]) => budget(i) - paid(i, p);
export function status(i: Item, p: Payment[]) {
  if (i.status === "cancelled") return "cancelled";
  let b = remaining(i, p),
    n = paid(i, p);
  if (n > 0 && b <= 0) return "paid";
  if (b > 0 && i.due && i.due < today()) return "late";
  if (n > 0) return "partial";
  return i.status;
}
export const statusNames: Record<string, string> = {
  planned: "Planejado",
  quoted: "Cotado",
  confirmed: "Confirmado",
  cancelled: "Cancelado",
  paid: "Pago",
  partial: "Parcial",
  late: "Atrasado",
};
export function totals(items: Item[], payments: Payment[]) {
  let active = items.filter((i) => i.status !== "cancelled");
  let b = active.reduce((s, i) => s + budget(i), 0),
    p = active.reduce((s, i) => s + paid(i, payments), 0);
  return {
    budget: b,
    paid: p,
    remaining: b - p,
    percent: b ? Math.min(100, Math.round((p / b) * 100)) : 0,
    done: active.filter((i) => status(i, payments) === "paid").length,
    late: active.filter((i) => status(i, payments) === "late").length,
    count: active.length,
  };
}
const isObj = (v: unknown): v is Record<string, unknown> =>
  !!v && typeof v === "object" && !Array.isArray(v);
const str = (v: unknown, max = 20000): v is string =>
  typeof v === "string" && v.length <= max;
export function validRecord(
  entity: Entity,
  v: unknown,
  key: string,
): v is RecordValue {
  if (!isObj(v) || v.id !== key || !str(v.id, 200)) return false;
  if (entity === "project")
    return (
      str(v.name, 200) &&
      !!v.name.trim() &&
      str(v.description) &&
      ["blank", "budget", "event"].includes(v.type as string) &&
      /^#[0-9a-fA-F]{6}$/.test(String(v.color)) &&
      ["table", "cards"].includes(v.view as string) &&
      Array.isArray(v.columns) &&
      v.columns.length <= 50 &&
      v.columns.every(
        (c: unknown) =>
          isObj(c) &&
          str(c.id, 200) &&
          str(c.name, 100) &&
          ["text", "number", "date", "choice"].includes(c.type as string),
      )
    );
  if (entity === "item")
    return (
      str(v.projectId, 200) &&
      str(v.description, 200) &&
      !!v.description.trim() &&
      str(v.supplier, 200) &&
      str(v.category, 200) &&
      typeof v.quantity === "number" &&
      v.quantity > 0 &&
      v.quantity <= 1e7 &&
      Number.isSafeInteger(v.unitCents) &&
      Number(v.unitCents) >= 0 &&
      Number(v.unitCents) <= 1e12 &&
      (v.budgetCents === null ||
        (Number.isSafeInteger(v.budgetCents) &&
          Number(v.budgetCents) >= 0 &&
          Number(v.budgetCents) <= 1e12)) &&
      str(v.due, 10) &&
      validDate(v.due) &&
      ["planned", "quoted", "confirmed", "cancelled"].includes(
        v.status as string,
      ) &&
      str(v.notes) &&
      isObj(v.custom) &&
      Object.keys(v.custom).length <= 50 &&
      Object.values(v.custom).every((x) => str(x, 2000))
    );
  if (entity === "payment") {
    if (!(
      str(v.itemId, 200) &&
      Number.isSafeInteger(v.amountCents) &&
      Number(v.amountCents) > 0 &&
      Number(v.amountCents) <= 1e12 &&
      str(v.date, 10) &&
      !!v.date &&
      validDate(v.date) &&
      str(v.method, 200) &&
      !!v.method.trim() &&
      str(v.notes)
    ))
      return false;
    if (v.receipt !== undefined) {
      let r = v.receipt;
      return (
        isObj(r) &&
        str(r.name, 255) &&
        str(r.type, 50) &&
        [
          "image/png",
          "image/jpeg",
          "image/webp",
          "image/gif",
          "application/pdf",
        ].includes(r.type) &&
        str(r.data, 8e6) &&
        r.data.startsWith("data:" + r.type + ";base64,") &&
        /^[A-Za-z0-9+/=]+$/.test(r.data.slice(r.data.indexOf(",") + 1))
      );
    }
    return true;
  }
  return false;
}
export function validOp(op: unknown): op is Op {
  return (
    isObj(op) &&
    str(op.id, 200) &&
    !!op.id &&
    str(op.actor, 200) &&
    Number.isSafeInteger(op.clock) &&
    Number(op.clock) >= 1 &&
    ["project", "item", "payment"].includes(op.entity as string) &&
    str(op.key, 200) &&
    Array.isArray(op.parents) &&
    op.parents.length <= 100 &&
    op.parents.every((p) => str(p, 200) && p !== op.id) &&
    str(op.time, 50) &&
    (op.value === null ||
      validRecord(op.entity as Entity, op.value, String(op.key)))
  );
}
export class Ledger {
  readonly ops = new Map<string, Op>();
  constructor(ops: Op[] = []) {
    this.ingest(ops);
  }
  ingest(ops: Op[]): Op[] {
    let added: Op[] = [];
    for (let op of ops) {
      if (!validOp(op)) throw Error("Alteração inválida recebida.");
      let old = this.ops.get(op.id);
      if (old) {
        if (JSON.stringify(old) !== JSON.stringify(op))
          throw Error(
            "Identificador de alteração duplicado com conteúdo diferente.",
          );
        continue;
      }
      this.ops.set(op.id, structuredClone(op));
      added.push(op);
    }
    return added;
  }
  heads(entity: Entity, key: string): Op[] {
    let all = [...this.ops.values()].filter(
        (o) => o.entity === entity && o.key === key,
      ),
      parents = new Set(all.flatMap((o) => o.parents));
    return all
      .filter((o) => !parents.has(o.id))
      .sort((a, b) => a.id.localeCompare(b.id));
  }
  create(
    actor: string,
    entity: Entity,
    key: string,
    value: RecordValue | null,
  ): Op {
    let clock =
      Math.max(
        0,
        ...[...this.ops.values()]
          .filter((o) => o.actor === actor)
          .map((o) => o.clock),
      ) + 1;
    let op: Op = {
      id: uuid(),
      actor,
      entity,
      key,
      value,
      parents: this.heads(entity, key).map((o) => o.id),
      clock,
      time: new Date().toISOString(),
    };
    if (!validOp(op)) throw Error("Registro inválido. Revise os campos.");
    return op;
  }
  snapshot(): Snapshot {
    let out: Snapshot = {
      projects: [],
      items: [],
      payments: [],
      conflicts: [],
    };
    let seen = new Set<string>();
    for (let op of this.ops.values()) {
      let key = op.entity + ":" + op.key;
      if (seen.has(key)) continue;
      seen.add(key);
      let heads = this.heads(op.entity, op.key);
      if (heads.length > 1)
        out.conflicts.push({ entity: op.entity, key: op.key, heads });
      let chosen = heads.find((o) => o.value !== null);
      if (!chosen) continue;
      if (op.entity === "project") out.projects.push(chosen.value as Project);
      if (op.entity === "item") out.items.push(chosen.value as Item);
      if (op.entity === "payment") {
        // Never count a disputed payment until explicitly resolved.
        if (heads.length === 1) out.payments.push(chosen.value as Payment);
      }
    }
    out.projects.sort((a, b) => a.name.localeCompare(b.name));
    return out;
  }
  export() {
    return [...this.ops.values()].sort(
      (a, b) =>
        a.actor.localeCompare(b.actor) ||
        a.clock - b.clock ||
        a.id.localeCompare(b.id),
    );
  }
}
export const defaultProject = (name: string): Project => ({
  id: uuid(),
  name,
  description: "",
  type: "blank",
  color: "#0969cf",
  view: "table",
  columns: [],
});
export const defaultItem = (projectId: string): Item => ({
  id: uuid(),
  projectId,
  description: "",
  supplier: "",
  category: "",
  quantity: 1,
  unitCents: 0,
  budgetCents: null,
  due: "",
  status: "planned",
  notes: "",
  custom: {},
});
