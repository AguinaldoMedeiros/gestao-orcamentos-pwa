import {
  Ledger,
  validOp,
  type Op,
  type Entity,
  type RecordValue,
  type Snapshot,
  uuid,
} from "./model";
let dbPromise: Promise<IDBDatabase> | null = null;
export function database() {
  if (!dbPromise)
    dbPromise = new Promise<IDBDatabase>((resolve, reject) => {
      let r = indexedDB.open("gestao-orcamentos", 1);
      r.onupgradeneeded = () => {
        let db = r.result;
        db.createObjectStore("ops", { keyPath: "id" });
        db.createObjectStore("meta");
      };
      r.onsuccess = () => {
        r.result.onversionchange = () => r.result.close();
        resolve(r.result);
      };
      r.onerror = () => {
        dbPromise = null;
        reject(r.error);
      };
    });
  return dbPromise;
}
async function read<T>(store: string, key?: IDBValidKey): Promise<T> {
  let db = await database();
  return new Promise((resolve, reject) => {
    let tx = db.transaction(store),
      r =
        key === undefined
          ? tx.objectStore(store).getAll()
          : tx.objectStore(store).get(key);
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}
export async function meta<T>(key: string, fallback: T): Promise<T> {
  return (await read<T>("meta", key)) ?? fallback;
}
export async function setMeta(key: string, value: unknown) {
  let db = await database();
  return new Promise<void>((resolve, reject) => {
    let tx = db.transaction("meta", "readwrite");
    tx.objectStore("meta").put(value, key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}
export class Store {
  ledger = new Ledger();
  observed = new WeakMap<RecordValue, string[]>();
  actor = "";
  snapshot: Snapshot = { projects: [], items: [], payments: [], conflicts: [] };
  listeners = new Set<() => void>();
  onOps = new Set<(ops: Op[]) => void>();
  channel: BroadcastChannel | null = null;
  busy = Promise.resolve();
  async init() {
    this.actor = await meta("actor", "");
    if (!this.actor) {
      this.actor = uuid();
      await setMeta("actor", this.actor);
    }
    this.ledger = new Ledger(await read<Op[]>("ops"));
    this.refresh();
    if (typeof BroadcastChannel !== "undefined") {
      this.channel = new BroadcastChannel("gestao-orcamentos-local");
      this.channel.onmessage = () => void this.reload();
    }
    return this;
  }
  async reload() {
    this.ledger.ingest(await read<Op[]>("ops"));
    this.refresh();
  }
  refresh() {
    this.snapshot = this.ledger.snapshot();
    for (let [entity, values] of [
      ["project", this.snapshot.projects],
      ["item", this.snapshot.items],
      ["payment", this.snapshot.payments],
    ] as const)
      for (let value of values)
        if (!this.observed.has(value))
          this.observed.set(
            value,
            this.ledger.heads(entity, value.id).map((o) => o.id),
          );
    this.listeners.forEach((l) => l());
  }
  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };
  getSnapshot = () => this.snapshot;
  async accept(ops: Op[], broadcast = true) {
    if (!ops.every(validOp)) throw Error("Pacote de alterações inválido.");
    let added: Op[] = [];
    let run = async () => {
      let db = await database();
      await new Promise<void>((resolve, reject) => {
        let tx = db.transaction("ops", "readwrite"),
          store = tx.objectStore("ops");
        for (let op of ops) {
          let request = store.get(op.id);
          request.onsuccess = () => {
            let existing = request.result as Op | undefined;
            if (existing && JSON.stringify(existing) !== JSON.stringify(op)) {
              tx.abort();
              return;
            }
            if (!existing) {
              store.add(op);
              added.push(op);
            }
          };
        }
        tx.oncomplete = () => resolve();
        tx.onerror = () =>
          reject(tx.error || Error("Não foi possível gravar."));
        tx.onabort = () =>
          reject(tx.error || Error("Conflito no identificador de alteração."));
      });
      this.ledger.ingest(added);
      this.refresh();
      if (added.length) {
        this.channel?.postMessage({ changed: true });
        if (broadcast) this.onOps.forEach((fn) => fn(added));
      }
    };
    let next = this.busy.then(run);
    this.busy = next.catch(() => {});
    await next;
    return added;
  }
  async write(
    entity: Entity,
    key: string,
    value: RecordValue | null,
    base?: RecordValue,
  ) {
    let expected = base ? this.observed.get(base) : undefined;
    await this.reload();
    let op = this.ledger.create(this.actor, entity, key, value);
    if (expected) op.parents = expected;
    await this.accept([op]);
    return op;
  }
  async batch(
    records: { entity: Entity; key: string; value: RecordValue | null }[],
  ) {
    await this.reload();
    let draft = new Ledger(this.ledger.export()),
      ops: Op[] = [];
    for (let r of records) {
      let op = draft.create(this.actor, r.entity, r.key, r.value);
      draft.ingest([op]);
      ops.push(op);
    }
    await this.accept(ops);
  }
  async replace(ops: Op[]) {
    let ledger = new Ledger(ops),
      db = await database();
    await new Promise<void>((resolve, reject) => {
      let tx = db.transaction("ops", "readwrite"),
        s = tx.objectStore("ops");
      s.clear();
      ledger.export().forEach((o) => s.add(o));
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
    this.ledger = ledger;
    this.refresh();
    this.channel?.postMessage({ changed: true });
  }
}
export const store = new Store();
