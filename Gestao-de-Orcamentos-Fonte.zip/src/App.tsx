import React, {
  useState,
  useEffect,
  useRef,
  useSyncExternalStore,
  type FormEvent,
  type ReactNode,
} from "react";
import {
  Folder,
  Wallet,
  LayoutGrid,
  List,
  Plus,
  Search,
  Settings,
  Download,
  RefreshCw,
  Sun,
  Moon,
  X,
  ArrowLeft,
  ArrowRight,
  MoreHorizontal,
  Check,
  Trash2,
  Copy,
  Monitor,
  Link2,
  ShieldCheck,
  Columns3,
  Upload,
  FileText,
  AlertTriangle,
  ChevronUp,
  ChevronDown,
  Wifi,
  WifiOff,
  Save,
} from "lucide-react";
import { store, meta, setMeta } from "./database";
import {
  type Project,
  type Item,
  type Payment,
  type Column,
  type Entity,
  type RecordValue,
  type Conflict,
  defaultProject,
  defaultItem,
  uuid,
  money,
  cents,
  budget,
  paid,
  remaining,
  status,
  statusNames,
  totals,
  today,
  brDate,
  validDate,
} from "./model";
import { sync } from "./sync";
import {
  pwaState,
  pwaVersion,
  subscribePwa,
  install,
  initializePwa,
  checkUpdate,
  applyUpdate,
} from "./pwa";
import {
  backup,
  importBackup,
  readReceipt,
  receiptURL,
  exportPdf,
  exportXlsx,
  spreadsheetRows,
  mappedRecords,
  mappingLabels,
  importLegacy,
  type MappingField,
} from "./io";
type Modal =
  | { type: "project"; project?: Project }
  | { type: "item"; item?: Item }
  | { type: "payment"; item: Item; payment?: Payment }
  | { type: "payment-detail"; payment: Payment }
  | { type: "columns" }
  | { type: "new-column" }
  | { type: "sync" }
  | { type: "install" }
  | { type: "updates" }
  | { type: "import"; rows?: Record<string, unknown>[] }
  | { type: "conflicts" }
  | { type: "project-menu"; project: Project };
type Field =
  | "description"
  | "category"
  | "supplier"
  | "quantity"
  | "unitCents"
  | "budgetCents"
  | "paid"
  | "remaining"
  | "status"
  | "due"
  | "method"
  | string;
const basicColumns = [
  ["description", "Descrição"],
  ["supplier", "Fornecedor"],
  ["budgetCents", "Orçado"],
  ["paid", "Pago"],
  ["remaining", "Restante"],
  ["status", "Status"],
  ["due", "Vencimento"],
  ["category", "Categoria"],
  ["quantity", "Qtd."],
  ["unitCents", "Valor unitário"],
  ["method", "Último método"],
];
const defaultColumns = [
  "description",
  "supplier",
  "budgetCents",
  "paid",
  "remaining",
  "status",
  "due",
];
function Btn({
  children,
  onClick,
  primary = false,
  danger = false,
  type = "button",
  disabled = false,
  title,
  className = "",
}: {
  children: ReactNode;
  onClick?: () => void;
  primary?: boolean;
  danger?: boolean;
  type?: "button" | "submit";
  disabled?: boolean;
  title?: string;
  className?: string;
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      className={`${primary ? "primary " : ""}${danger ? "danger " : ""}${className}`}
      disabled={disabled}
      title={title}
    >
      {children}
    </button>
  );
}
function Badge({ item, payments }: { item: Item; payments: Payment[] }) {
  let s = status(item, payments);
  return <span className={"badge " + s}>{statusNames[s]}</span>;
}
function Progress({ percent }: { percent: number }) {
  return (
    <div
      className="track"
      role="progressbar"
      aria-label="Percentual quitado"
      aria-valuenow={percent}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <span style={{ width: Math.max(0, Math.min(100, percent)) + "%" }} />
    </div>
  );
}
function Summary({ items, payments }: { items: Item[]; payments: Payment[] }) {
  let t = totals(items, payments);
  return (
    <div className="stats">
      <div className="stat">
        <label>Total orçado</label>
        <strong>{money(t.budget)}</strong>
        <small>{t.count} itens ativos</small>
      </div>
      <div className="stat">
        <label>Total pago</label>
        <strong className="green">{money(t.paid)}</strong>
        <small>Pagamentos registrados</small>
      </div>
      <div className="stat">
        <label>Restante a pagar</label>
        <strong>{money(t.remaining)}</strong>
        <small>{t.late} itens em atraso</small>
      </div>
      <div className="stat">
        <label>Progresso de quitação</label>
        <strong>{t.percent}%</strong>
        <Progress percent={t.percent} />
        <small>
          {t.done} de {t.count} itens quitados
        </small>
      </div>
    </div>
  );
}
function Receipt({ payment }: { payment: Payment }) {
  let [url, setUrl] = useState("");
  useEffect(() => {
    if (!payment.receipt) return;
    let u = receiptURL(payment);
    setUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [payment]);
  return !payment.receipt ? (
    <p>Nenhum comprovante anexado.</p>
  ) : (
    <>
      <p className="micro">{payment.receipt.name}</p>
      <div className="receiptviewer">
        {payment.receipt.type === "application/pdf" ? (
          <iframe title="Comprovante em PDF" src={url} />
        ) : (
          <img src={url} alt={"Comprovante: " + payment.receipt.name} />
        )}
      </div>
      <a
        className="receipt-download"
        href={url}
        download={payment.receipt.name}
      >
        <Download /> Salvar cópia do comprovante
      </a>
    </>
  );
}
function DataList({ id, values }: { id: string; values: string[] }) {
  return (
    <datalist id={id}>
      {[...new Set(values.filter(Boolean))]
        .sort((a, b) => a.localeCompare(b))
        .map((v) => (
          <option key={v} value={v} />
        ))}
    </datalist>
  );
}
export default function App() {
  const data = useSyncExternalStore(store.subscribe, store.getSnapshot);
  useSyncExternalStore(sync.subscribe, sync.getVersion);
  useSyncExternalStore(subscribePwa, pwaVersion);
  const [page, setPage] = useState("projects"),
    [projectId, setProjectId] = useState(""),
    [homeView, setHomeView] = useState("cards"),
    [view, setView] = useState("table"),
    [query, setQuery] = useState(""),
    [filter, setFilter] = useState(""),
    [cat, setCat] = useState(""),
    [supplier, setSupplier] = useState(""),
    [due, setDue] = useState(""),
    [sort, setSort] = useState("description"),
    [group, setGroup] = useState(""),
    [theme, setTheme] = useState("light"),
    [modal, setModal] = useState<Modal | null>(null),
    [dirty, setDirty] = useState(false),
    [message, setMessage] = useState(""),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [sheet, setSheet] = useState(false),
    [cell, setCell] = useState<{
      id: string;
      field: Field;
      value: string;
    } | null>(null),
    [visible, setVisible] = useState<string[]>(defaultColumns),
    [order, setOrder] = useState<string[]>([]),
    [online, setOnline] = useState(navigator.onLine),
    [pairOutput, setPairOutput] = useState(""),
    [pairInput, setPairInput] = useState(""),
    [pairId, setPairId] = useState(""),
    [persistent, setPersistent] = useState(false);
  const rowTimer = useRef<ReturnType<typeof setTimeout> | null>(null),
    modalRef = useRef<HTMLDivElement>(null),
    returnFocus = useRef<HTMLElement | null>(null),
    modalState = useRef(modal),
    projectViews = useRef(
      new Map<
        string,
        {
          query: string;
          filter: string;
          cat: string;
          supplier: string;
          due: string;
          view: string;
          sort: string;
          group: string;
        }
      >(),
    );
  modalState.current = modal;
  const project = data.projects.find((p) => p.id === projectId),
    projectItems = data.items.filter((i) => i.projectId === projectId),
    projectPayments = data.payments.filter((p) =>
      projectItems.some((i) => i.id === p.itemId),
    ),
    allColumns = [
      ...basicColumns.map(([id, name]) => ({
        id,
        name,
        type: "text" as const,
      })),
      ...(project?.columns || []),
    ];
  let sortedColumns = order.length
    ? ([
        ...order
          .map((id) => allColumns.find((c) => c.id === id))
          .filter(Boolean),
        ...allColumns.filter((c) => !order.includes(c.id)),
      ] as Column[])
    : allColumns;
  let columns = sortedColumns.filter(
    (c) =>
      visible.includes(c.id) ||
      (project?.columns.some((x) => x.id === c.id) &&
        !visible.includes("!" + c.id)),
  );
  useEffect(() => {
    void meta("theme", "light").then(setTheme);
    void navigator.storage?.persisted?.().then(setPersistent);
    void initializePwa();
    const on = () => setOnline(navigator.onLine);
    window.addEventListener("online", on);
    window.addEventListener("offline", on);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", on);
    };
  }, []);
  useEffect(() => {
    document.body.classList.toggle(
      "dark",
      theme === "dark" ||
        (theme === "system" &&
          matchMedia("(prefers-color-scheme: dark)").matches),
    );
    void setMeta("theme", theme);
  }, [theme]);
  useEffect(() => {
    if (!message) return;
    let t = setTimeout(() => setMessage(""), 4500);
    return () => clearTimeout(t);
  }, [message]);
  useEffect(() => {
    if (!projectId) return;
    void meta<{ visible: string[]; order: string[] }>("columns:" + projectId, {
      visible: defaultColumns,
      order: [],
    }).then((v) => {
      setVisible(v.visible);
      setOrder(v.order);
    });
  }, [projectId]);
  useEffect(() => {
    if (!modal) return;
    let prev = document.activeElement as HTMLElement;
    returnFocus.current = prev;
    setTimeout(() => {
      let e = modalRef.current?.querySelector<HTMLInputElement>(
        "input:not([type=file]),select",
      );
      (e || modalRef.current?.querySelector<HTMLElement>("h2"))?.focus();
    }, 0);
    return () => {
      if (prev?.isConnected) prev.focus();
    };
  }, [modal?.type]);
  function notify(s: string) {
    setMessage(s);
  }
  function close() {
    if (dirty && !confirm("Descartar as alterações não salvas?")) return;
    setModal(null);
    setDirty(false);
    setError("");
  }
  function open(next: Modal) {
    if (dirty && !confirm("Descartar as alterações não salvas?")) return;
    setDirty(false);
    setError("");
    setModal(next);
  }
  function handleError(e: unknown) {
    setError(e instanceof Error ? e.message : String(e));
  }
  async function run(fn: () => Promise<void>) {
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      await fn();
    } catch (e) {
      handleError(e);
    } finally {
      setBusy(false);
    }
  }
  function go(p: string) {
    if (rowTimer.current) clearTimeout(rowTimer.current);
    if (page === "detail")
      projectViews.current.set(projectId, {
        query,
        filter,
        cat,
        supplier,
        due,
        view,
        sort,
        group,
      });
    setPage(p);
    setQuery("");
    setFilter("");
    setCell(null);
    setSheet(false);
  }
  function enter(p: Project) {
    if (page === "detail")
      projectViews.current.set(projectId, {
        query,
        filter,
        cat,
        supplier,
        due,
        view,
        sort,
        group,
      });
    let v = projectViews.current.get(p.id);
    setProjectId(p.id);
    setView(v?.view || p.view);
    setQuery(v?.query || "");
    setFilter(v?.filter || "");
    setCat(v?.cat || "");
    setSupplier(v?.supplier || "");
    setDue(v?.due || "");
    setSort(v?.sort || "description");
    setGroup(v?.group || "");
    setCell(null);
    setSheet(false);
    setPage("detail");
  }
  const suppliers = [...new Set(data.items.map((i) => i.supplier))],
    categories = [...new Set(data.items.map((i) => i.category))],
    methods = [
      ...new Set([
        "Pix",
        "Dinheiro",
        "Cartão de crédito",
        "Cartão de débito",
        "Transferência",
        "Outro",
        ...data.payments.map((p) => p.method),
      ]),
    ];
  let filtered = projectItems
    .filter(
      (i) =>
        (i.description + " " + i.supplier + " " + i.category)
          .toLowerCase()
          .includes(query.toLowerCase()) &&
        (!filter || status(i, data.payments) === filter) &&
        (!cat || i.category === cat) &&
        (!supplier || i.supplier === supplier) &&
        (!due ||
          (due === "late"
            ? status(i, data.payments) === "late"
            : due === "none"
              ? !i.due
              : i.due >= today() &&
                i.due <=
                  new Date(Date.now() + 7 * 86400000).toLocaleDateString(
                    "sv-SE",
                  ) &&
                remaining(i, data.payments) > 0)),
    )
    .sort((a, b) =>
      sort === "budget"
        ? budget(b) - budget(a)
        : sort === "remaining"
          ? remaining(b, data.payments) - remaining(a, data.payments)
          : sort === "due"
            ? (a.due || "9999").localeCompare(b.due || "9999")
            : sort === "status"
              ? status(a, data.payments).localeCompare(status(b, data.payments))
              : a.description.localeCompare(b.description),
    );
  function clearFilters() {
    setQuery("");
    setFilter("");
    setCat("");
    setSupplier("");
    setDue("");
  }
  async function persistColumns(v: string[], o: string[]) {
    setVisible(v);
    setOrder(o);
    await setMeta("columns:" + projectId, { visible: v, order: o });
  }
  function eventForm(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    return Object.fromEntries(new FormData(e.currentTarget)) as Record<
      string,
      FormDataEntryValue
    >;
  }
  async function saveProject(e: FormEvent<HTMLFormElement>, old?: Project) {
    let f = eventForm(e);
    await run(async () => {
      let p: Project = {
        ...(old || defaultProject(String(f.name))),
        name: String(f.name).trim(),
        description: String(f.description),
        type: f.type as Project["type"],
        color: String(f.color),
        view: f.view as Project["view"],
      };
      if (!p.name) throw Error("Informe o nome do projeto.");
      let records: {
        entity: Entity;
        key: string;
        value: RecordValue | null;
      }[] = [{ entity: "project", key: p.id, value: p }];
      if (!old && p.type === "event")
        for (let description of [
          "Cerimonial",
          "Espaço",
          "Decoração",
          "Buffet",
          "Som e iluminação",
          "Fotografia",
          "Filmagem",
          "Bolo",
          "Doces",
          "Lembrancinhas",
          "Plataforma 360°",
          "Convite",
          "Animadores",
          "DJ",
          "Apoio",
        ]) {
          let i = { ...defaultItem(p.id), description };
          records.push({ entity: "item", key: i.id, value: i });
        }
      if (old) await store.write("project", p.id, p, old);
      else await store.batch(records);
      setDirty(false);
      setModal(null);
      enter(p);
      notify("Projeto salvo.");
    });
  }
  async function duplicate(p: Project) {
    await run(async () => {
      let copy = { ...p, id: uuid(), name: p.name + " (cópia)" },
        records: { entity: Entity; key: string; value: RecordValue | null }[] =
          [{ entity: "project", key: copy.id, value: copy }];
      for (let item of data.items.filter((i) => i.projectId === p.id)) {
        let next = { ...item, id: uuid(), projectId: copy.id };
        records.push({ entity: "item", key: next.id, value: next });
        for (let payment of data.payments.filter((x) => x.itemId === item.id)) {
          let pay = { ...payment, id: uuid(), itemId: next.id };
          records.push({ entity: "payment", key: pay.id, value: pay });
        }
      }
      await store.batch(records);
      setModal(null);
      enter(copy);
      notify("Projeto duplicado com itens e pagamentos.");
    });
  }
  async function deleteProject(p: Project) {
    if (
      !confirm(
        "Excluir o projeto, os itens e os pagamentos? A exclusão será sincronizada com os dispositivos conectados.",
      )
    )
      return;
    await run(async () => {
      let items = data.items.filter((i) => i.projectId === p.id),
        payments = data.payments.filter((pay) =>
          items.some((i) => i.id === pay.itemId),
        );
      await store.batch([
        { entity: "project", key: p.id, value: null },
        ...items.map((i) => ({
          entity: "item" as const,
          key: i.id,
          value: null,
        })),
        ...payments.map((p) => ({
          entity: "payment" as const,
          key: p.id,
          value: null,
        })),
      ]);
      setModal(null);
      go("projects");
      notify("Projeto excluído.");
    });
  }
  async function saveItem(e: FormEvent<HTMLFormElement>, old?: Item) {
    let f = eventForm(e);
    await run(async () => {
      let i: Item = {
        ...(old || defaultItem(projectId)),
        description: String(f.description).trim(),
        supplier: String(f.supplier).trim(),
        category: String(f.category || "").trim(),
        quantity:
          f.quantity === "" ? 1 : Number(String(f.quantity).replace(",", ".")),
        unitCents: cents(String(f.unit || 0)),
        budgetCents: f.budget === "" ? null : cents(String(f.budget)),
        due: String(f.due || ""),
        status: (f.status || "planned") as Item["status"],
        notes: String(f.notes || ""),
        custom: {},
      };
      if (!i.description || !i.supplier)
        throw Error("Preencha descrição e fornecedor.");
      for (let c of project?.columns || [])
        i.custom[c.id] = String(f["custom:" + c.id] || "");
      if (
        paid(i, data.payments) > budget(i) &&
        old &&
        budget(old) !== budget(i) &&
        !confirm("O orçamento ficará abaixo do valor já pago. Confirmar?")
      )
        return;
      await store.write("item", i.id, i, old);
      setDirty(false);
      setModal(null);
      notify("Item salvo. Totais atualizados.");
    });
  }
  async function deleteItem(i: Item) {
    if (!confirm("Excluir o item e seus pagamentos?")) return;
    await run(async () => {
      await store.batch([
        { entity: "item", key: i.id, value: null },
        ...data.payments
          .filter((p) => p.itemId === i.id)
          .map((p) => ({ entity: "payment" as const, key: p.id, value: null })),
      ]);
      setDirty(false);
      setModal(null);
      notify("Item excluído.");
    });
  }
  async function savePayment(
    e: FormEvent<HTMLFormElement>,
    i: Item,
    old?: Payment,
  ) {
    let f = eventForm(e);
    await run(async () => {
      let p: Payment = {
        ...(old || { id: uuid() }),
        itemId: i.id,
        amountCents: cents(String(f.amount)),
        date: String(f.date),
        method: String(f.method).trim(),
        notes: String(f.notes || ""),
      };
      if (p.amountCents <= 0 || !p.date || !validDate(p.date) || !p.method)
        throw Error("Informe valor, data e método válidos.");
      if (
        paid(i, data.payments) - (old?.amountCents || 0) + p.amountCents >
          budget(i) &&
        !confirm(
          "Este pagamento ultrapassa o orçamento. Confirmar explicitamente o excedente?",
        )
      )
        return;
      let file = f.receipt as File;
      if (file?.size) p.receipt = await readReceipt(file);
      if (f.removeReceipt === "on") delete p.receipt;
      await store.write("payment", p.id, p, old);
      setDirty(false);
      setModal({ type: "payment-detail", payment: p });
      notify("Pagamento e comprovante salvos neste dispositivo.");
    });
  }
  async function removePayment(p: Payment) {
    if (!confirm("Excluir este pagamento e recalcular o saldo?")) return;
    await run(async () => {
      await store.write("payment", p.id, null);
      setModal({
        type: "item",
        item: data.items.find((i) => i.id === p.itemId),
      });
      notify("Pagamento removido.");
    });
  }
  function rawCell(i: Item, field: string) {
    if (field === "unitCents") return String(i.unitCents / 100);
    if (field === "budgetCents")
      return i.budgetCents === null ? "" : String(i.budgetCents / 100);
    if (field in i) return String(i[field as keyof Item] ?? "");
    return i.custom[field] || "";
  }
  async function finishCell(
    value?: string,
    next?: { id: string; field: string },
  ) {
    if (!cell) return;
    let edit = cell,
      old = data.items.find((i) => i.id === edit.id);
    if (!old) return;
    let v = value ?? edit.value;
    if (v === rawCell(old, edit.field)) {
      setCell(
        next
          ? {
              ...next,
              value: rawCell(
                data.items.find((i) => i.id === next.id)!,
                next.field,
              ),
            }
          : null,
      );
      return;
    }
    let item = structuredClone(old);
    try {
      if (["unitCents", "budgetCents"].includes(edit.field)) {
        let n = edit.field === "budgetCents" && !v.trim() ? null : cents(v);
        if (n !== null && n < 0)
          throw Error("Valores não podem ser negativos.");
        if (edit.field === "unitCents") item.unitCents = n || 0;
        else item.budgetCents = n;
      } else if (edit.field === "quantity") {
        item.quantity = v.trim() ? Number(v.replace(",", ".")) : 1;
        if (!Number.isFinite(item.quantity) || item.quantity <= 0)
          throw Error("Quantidade inválida.");
      } else if (
        ["description", "supplier", "category", "due", "status"].includes(
          edit.field,
        )
      ) {
        Object.assign(item, { [edit.field]: v.trim() });
        if (["description", "supplier"].includes(edit.field) && !v.trim())
          throw Error("Este campo é obrigatório.");
        if (edit.field === "due" && !validDate(v))
          throw Error("Data inválida.");
      } else item.custom[edit.field] = v;
      if (
        paid(item, data.payments) > budget(item) &&
        budget(item) !== budget(old) &&
        !confirm("O orçamento ficará abaixo do pago. Confirmar?")
      )
        return;
      await store.write("item", item.id, item, old);
      setCell(
        next
          ? {
              ...next,
              value: rawCell(
                data.items.find((i) => i.id === next.id)!,
                next.field,
              ),
            }
          : null,
      );
    } catch (e) {
      notify(e instanceof Error ? e.message : String(e));
    }
  }
  function editable(f: string) {
    return !["paid", "remaining", "method"].includes(f);
  }
  function cellKey(
    e: React.KeyboardEvent<HTMLInputElement | HTMLSelectElement>,
    i: Item,
    f: string,
  ) {
    if (e.key === "Escape") {
      e.stopPropagation();
      setCell(null);
      return;
    }
    if (!["Enter", "Tab"].includes(e.key)) return;
    e.preventDefault();
    e.stopPropagation();
    let editableColumns = columns.filter((c) => editable(c.id)),
      r = filtered.findIndex((x) => x.id === i.id),
      c = editableColumns.findIndex((x) => x.id === f),
      nr = r,
      nc = c;
    if (e.key === "Enter") nr += e.shiftKey ? -1 : 1;
    else {
      nc += e.shiftKey ? -1 : 1;
      if (nc >= editableColumns.length) {
        nc = 0;
        nr++;
      }
      if (nc < 0) {
        nc = editableColumns.length - 1;
        nr--;
      }
    }
    let next =
      filtered[nr] && editableColumns[nc]
        ? { id: filtered[nr].id, field: editableColumns[nc].id }
        : undefined;
    void finishCell(e.currentTarget.value, next);
  }
  function rowClick(e: React.MouseEvent, i: Item) {
    if ((e.target as HTMLElement).closest("button,input,select,textarea,a"))
      return;
    let f = (e.target as HTMLElement).closest<HTMLElement>("[data-field]")
      ?.dataset.field;
    if (sheet) {
      if (f && editable(f))
        setCell({ id: i.id, field: f, value: rawCell(i, f) });
      return;
    }
    if (rowTimer.current) clearTimeout(rowTimer.current);
    rowTimer.current = setTimeout(() => open({ type: "item", item: i }), 350);
  }
  function rowDouble(e: React.MouseEvent, i: Item) {
    if ((e.target as HTMLElement).closest("button,input,select,textarea,a"))
      return;
    e.preventDefault();
    if (rowTimer.current) clearTimeout(rowTimer.current);
    let f = (e.target as HTMLElement).closest<HTMLElement>("[data-field]")
      ?.dataset.field;
    setSheet(true);
    if (f && editable(f)) setCell({ id: i.id, field: f, value: rawCell(i, f) });
  }
  function renderCell(i: Item, c: Column) {
    let f = c.id;
    if (cell?.id === i.id && cell.field === f) {
      let props = {
        autoFocus: true,
        "aria-label": "Editar " + c.name + " de " + i.description,
        value: cell.value,
        onChange: (
          e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>,
        ) => setCell({ ...cell, value: e.target.value }),
        onKeyDown: (
          e: React.KeyboardEvent<HTMLInputElement | HTMLSelectElement>,
        ) => cellKey(e, i, f),
        onBlur: (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement>) => {
          if (!e.relatedTarget?.closest(".editablecell"))
            void finishCell(e.target.value);
        },
      };
      return f === "status" ? (
        <select {...props}>
          {["planned", "quoted", "confirmed", "cancelled"].map((s) => (
            <option key={s} value={s}>
              {statusNames[s]}
            </option>
          ))}
        </select>
      ) : (
        <input
          {...props}
          type={f === "due" || c.type === "date" ? "date" : "text"}
          list={
            f === "supplier"
              ? "suppliers"
              : f === "category"
                ? "categories"
                : c.type === "choice"
                  ? "custom-" + f
                  : undefined
          }
        />
      );
    }
    if (f === "description") return <b className="green">{i.description}</b>;
    if (f === "budgetCents")
      return budget(i) ? (
        money(budget(i))
      ) : (
        <span className="micro">A definir</span>
      );
    if (f === "unitCents") return money(i.unitCents);
    if (f === "paid") return money(paid(i, data.payments));
    if (f === "remaining") return <b>{money(remaining(i, data.payments))}</b>;
    if (f === "status") return <Badge item={i} payments={data.payments} />;
    if (f === "due") return brDate(i.due);
    if (f === "method")
      return (
        [...data.payments]
          .filter((p) => p.itemId === i.id)
          .sort((a, b) => b.date.localeCompare(a.date))[0]?.method || "—"
      );
    if (["supplier", "category", "quantity"].includes(f))
      return String(i[f as keyof Item] || "—");
    return i.custom[f]
      ? c.type === "date"
        ? brDate(i.custom[f])
        : i.custom[f]
      : "—";
  }
  function paymentButton(i: Item) {
    return (
      <Btn
        onClick={() => {
          if (rowTimer.current) clearTimeout(rowTimer.current);
          open({ type: "payment", item: i });
        }}
      >
        <Wallet /> Pagar
      </Btn>
    );
  }
  function itemCard(i: Item) {
    let t = totals([i], data.payments);
    return (
      <article className="card itemcard" key={i.id}>
        <div className={"cover " + status(i, data.payments)} />
        <div className="cardbody">
          <div className="row between">
            <small>{i.category || "Sem categoria"}</small>
            <Badge item={i} payments={data.payments} />
          </div>
          <h3>
            <button
              className="textbutton"
              onClick={() => open({ type: "item", item: i })}
            >
              {i.description}
            </button>
          </h3>
          <p>{i.supplier || "Fornecedor a definir"}</p>
          <div className="moneyrow">
            <div>
              <small>Orçado</small>
              <b>{budget(i) ? money(budget(i)) : "A definir"}</b>
            </div>
            <div>
              <small>Pago</small>
              <b>{money(paid(i, data.payments))}</b>
            </div>
          </div>
          <Progress percent={t.percent} />
          <div className="row between">
            <small>Restante</small>
            <b>{money(remaining(i, data.payments))}</b>
          </div>
          <p className="micro" style={{ marginTop: 18 }}>
            {brDate(i.due)}
          </p>
          {status(i, data.payments) === "late" && (
            <p className="danger micro">Pagamento vencido.</p>
          )}
          {paymentButton(i)}
          {project?.columns
            .filter((c) => i.custom[c.id])
            .map((c) => (
              <div key={c.id} className="row between micro">
                <span>{c.name}</span>
                <span>{i.custom[c.id]}</span>
              </div>
            ))}
        </div>
      </article>
    );
  }
  function history(i: Item) {
    return (
      <details id="item-payments" open>
        <summary>
          Histórico de pagamentos ·{" "}
          {data.payments.filter((p) => p.itemId === i.id).length}
        </summary>
        {data.payments
          .filter((p) => p.itemId === i.id)
          .sort((a, b) => b.date.localeCompare(a.date))
          .map((p) => (
            <button
              type="button"
              className="paymenthistoryrow"
              key={p.id}
              onClick={() => open({ type: "payment-detail", payment: p })}
            >
              <span>
                <b>{money(p.amountCents)}</b>
                <small>
                  {brDate(p.date)} · {p.method}
                </small>
              </span>
              <span className="paymentfilelabel">
                {p.receipt ? "📎 " + p.receipt.name : "Sem comprovante"}
                <ArrowRight />
              </span>
            </button>
          ))}
      </details>
    );
  }
  async function createColumn(e: FormEvent<HTMLFormElement>) {
    let f = eventForm(e);
    await run(async () => {
      if (!project) return;
      let name = String(f.name).trim();
      if (
        !name ||
        allColumns.some((c) => c.name.toLowerCase() === name.toLowerCase())
      )
        throw Error("Informe um nome único para a coluna.");
      let c: Column = { id: uuid(), name, type: f.type as Column["type"] };
      await store.write(
        "project",
        project.id,
        { ...project, columns: [...project.columns, c] },
        project,
      );
      setDirty(false);
      setModal(null);
      notify("Coluna criada. Os itens existentes permanecem em branco.");
    });
  }
  async function requestPersistent() {
    let ok = await navigator.storage?.persist?.();
    setPersistent(!!ok);
    notify(
      ok
        ? "Armazenamento persistente autorizado."
        : "O navegador não concedeu persistência. Mantenha seus backups.",
    );
  }
  async function demo() {
    await run(async () => {
      let p = {
          ...defaultProject("Evento de demonstração"),
          description: "Dados fictícios para experimentar o aplicativo.",
          type: "event" as const,
        },
        a = {
          ...defaultItem(p.id),
          description: "Espaço do evento",
          supplier: "Villa Jardim",
          category: "Espaço",
          budgetCents: 1200000,
          due: "2026-12-10",
          status: "confirmed" as const,
        },
        b = {
          ...defaultItem(p.id),
          description: "Decoração e flores",
          supplier: "Flor de Lis",
          category: "Decoração",
          budgetCents: 850000,
          status: "planned" as const,
        },
        payment: Payment = {
          id: uuid(),
          itemId: a.id,
          amountCents: 400000,
          date: today(),
          method: "Pix",
          notes: "Sinal fictício",
        };
      await store.batch([
        { entity: "project", key: p.id, value: p },
        { entity: "item", key: a.id, value: a },
        { entity: "item", key: b.id, value: b },
        { entity: "payment", key: payment.id, value: payment },
      ]);
      enter(p);
    });
  }
  function title() {
    return page === "detail"
      ? project?.name || "Projeto"
      : (
          {
            projects: "Meus projetos",
            payments: "Pagamentos",
            overview: "Visão geral",
            settings: "Configurações",
            storage: "Dados e backup",
          } as Record<string, string>
        )[page];
  }
  const overdue = data.items.filter(
    (i) =>
      status(i, data.payments) === "late" &&
      data.projects.some((p) => p.id === i.projectId),
  );
  const orphanPayments = data.payments.filter(
    (p) =>
      !data.items.some(
        (i) =>
          i.id === p.itemId &&
          data.projects.some((pr) => pr.id === i.projectId),
      ),
  );
  const excess = data.items.filter(
    (i) => remaining(i, data.payments) < 0 && i.status !== "cancelled",
  );
  return (
    <>
      <div className="app-shell" inert={!!modal}>
        <a className="skip" href="#content">
          Ir para o conteúdo
        </a>
        <aside>
          <div className="brand">
            <div className="brandicon">
              <Wallet />
            </div>
            <span>
              Gestão de
              <br />
              Orçamentos
            </span>
          </div>
          <div className="subbrand">Projetos e pagamentos</div>
          {[
            ["projects", "Projetos", Folder],
            ["overview", "Visão geral", LayoutGrid],
            ["payments", "Pagamentos", Wallet],
          ].map(([p, name, Icon]) => (
            <button
              key={String(p)}
              className={
                "nav " +
                (page === p || (page === "detail" && p === "projects")
                  ? "active"
                  : "")
              }
              onClick={() => go(String(p))}
            >
              {React.createElement(Icon)}
              <span>{String(name)}</span>
            </button>
          ))}
          <div className="navhead">PROJETOS</div>
          {data.projects.slice(0, 6).map((p) => (
            <button
              key={p.id}
              className={
                "navproject " +
                (page === "detail" && p.id === projectId ? "current" : "")
              }
              onClick={() => enter(p)}
            >
              <i />
              <span>{p.name}</span>
            </button>
          ))}
          <button
            className="navproject"
            onClick={() => open({ type: "project" })}
          >
            <Plus /> Novo projeto
          </button>
          <div className="sidebottom">
            <button className="nav" onClick={() => open({ type: "sync" })}>
              <Link2 />
              <span>
                Sincronização {sync.peers.size ? `(${sync.peers.size})` : ""}
              </span>
            </button>
            <button
              className={"nav " + (page === "storage" ? "active" : "")}
              onClick={() => go("storage")}
            >
              <ShieldCheck />
              <span>Dados e backup</span>
            </button>
            <button
              className={"nav " + (page === "settings" ? "active" : "")}
              onClick={() => go("settings")}
            >
              <Settings />
              <span>Configurações</span>
            </button>
            <div className="offline">
              {online ? <Wifi /> : <WifiOff />}
              <span>
                {online ? "Conectado · dados locais" : "Offline · dados locais"}
                <small>{store.ledger.ops.size} alterações salvas</small>
              </span>
            </div>
          </div>
        </aside>
        <main id="content">
          <header>
            <nav className="crumb" aria-label="Caminho">
              <button onClick={() => go("projects")}>Projetos</button>
              {page !== "projects" && (
                <>
                  <span>›</span>
                  <b>{title()}</b>
                </>
              )}
            </nav>
            <div className="row headerextras">
              <Btn
                onClick={() => open({ type: "install" })}
                title="Instalar como aplicativo"
              >
                <Monitor />
                <span className="header-label">
                  {pwaState.installed ? "Instalado" : "Instalar"}
                </span>
              </Btn>
              <Btn
                primary={pwaState.update}
                onClick={() => open({ type: "updates" })}
              >
                <RefreshCw />
                <span className="header-label">
                  {pwaState.update ? "Atualização pronta" : "Atualizações"}
                </span>
              </Btn>
              <Btn
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                title="Alternar tema"
              >
                {theme === "dark" ? <Sun /> : <Moon />}
              </Btn>
            </div>
          </header>
          <div className="wrap">
            {data.conflicts.length > 0 && (
              <button
                className="warningbanner"
                onClick={() => open({ type: "conflicts" })}
              >
                <AlertTriangle />
                {data.conflicts.length} conflito(s) de sincronização. Resolver
                antes de confiar nos totais.
                <ArrowRight />
              </button>
            )}
            {orphanPayments.length > 0 && (
              <button className="warningbanner" onClick={() => go("payments")}>
                <AlertTriangle />
                {orphanPayments.length} pagamento(s) com item ou projeto
                excluído durante a sincronização. Os registros e comprovantes
                foram preservados para revisão.
              </button>
            )}
            {excess.length > 0 && (
              <div className="warningbanner">
                <AlertTriangle />
                {excess.length} item(ns) com pagamentos acima do orçamento.
                Revise o histórico após a sincronização.
              </div>
            )}
            {page === "projects" && (
              <>
                <div className="heading row between">
                  <div>
                    <span className="eyebrow">Organização financeira</span>
                    <h1>Meus projetos</h1>
                    <p>
                      Acompanhe valores, pagamentos e vencimentos de cada
                      projeto.
                    </p>
                  </div>
                  <Btn primary onClick={() => open({ type: "project" })}>
                    <Plus /> Novo projeto
                  </Btn>
                </div>
                <Summary
                  items={data.items.filter((i) =>
                    data.projects.some((p) => p.id === i.projectId),
                  )}
                  payments={data.payments}
                />
                <div className="sectiontitle">
                  <h2>
                    Seus projetos <small>{data.projects.length} projetos</small>
                  </h2>
                  <span className="micro">Salvo neste dispositivo</span>
                </div>
                <div className="toolbar">
                  <div className="search">
                    <Search />
                    <input
                      aria-label="Buscar projetos"
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder="Buscar por nome ou tipo de projeto…"
                    />
                  </div>
                  <div className="seg">
                    <button
                      aria-pressed={homeView === "cards"}
                      className={homeView === "cards" ? "on" : ""}
                      onClick={() => setHomeView("cards")}
                    >
                      <LayoutGrid />
                      Cards
                    </button>
                    <button
                      aria-pressed={homeView === "list"}
                      className={homeView === "list" ? "on" : ""}
                      onClick={() => setHomeView("list")}
                    >
                      <List />
                      Lista
                    </button>
                  </div>
                </div>
                <div className={homeView === "cards" ? "grid" : "projectlist"}>
                  {data.projects
                    .filter((p) =>
                      (
                        p.name +
                        " " +
                        {
                          event: "evento",
                          budget: "orçamento",
                          blank: "em branco",
                        }[p.type]
                      )
                        .toLowerCase()
                        .includes(query.toLowerCase()),
                    )
                    .map((p) => {
                      let items = data.items.filter(
                          (i) => i.projectId === p.id,
                        ),
                        t = totals(items, data.payments);
                      return (
                        <article
                          key={p.id}
                          className={
                            "card " + (homeView === "list" ? "projectrow" : "")
                          }
                        >
                          <div
                            className="cover"
                            style={{ background: p.color }}
                          />
                          <div className="cardbody">
                            <div className="row between">
                              <div className="projecticon">
                                <Folder />
                              </div>
                              <button
                                title={"Ações de " + p.name}
                                onClick={() =>
                                  open({ type: "project-menu", project: p })
                                }
                              >
                                <MoreHorizontal />
                              </button>
                            </div>
                            <span className="tag">
                              {
                                {
                                  event: "Evento",
                                  budget: "Orçamento",
                                  blank: "Em branco",
                                }[p.type]
                              }
                            </span>
                            <h3>
                              <button
                                className="textbutton"
                                onClick={() => enter(p)}
                              >
                                {p.name}
                              </button>
                            </h3>
                            <p>{p.description || "Sem descrição"}</p>
                            <div className="moneyrow">
                              <div>
                                <small>Orçado</small>
                                <b>{money(t.budget)}</b>
                              </div>
                              <div>
                                <small>Pago</small>
                                <b className="green">{money(t.paid)}</b>
                              </div>
                              <div>
                                <small>Pendente</small>
                                <b>{money(t.remaining)}</b>
                              </div>
                            </div>
                            <Progress percent={t.percent} />
                            <div className="row between micro">
                              <span>{t.percent}% quitado</span>
                              <span>{items.length} itens</span>
                            </div>
                          </div>
                          <div className="cardfoot">
                            <span className={t.late ? "alert" : ""}>
                              {t.late ? `${t.late} em atraso` : "Tudo em dia"}
                            </span>
                            <button
                              className="textbutton"
                              onClick={() => enter(p)}
                            >
                              Abrir projeto <ArrowRight />
                            </button>
                          </div>
                        </article>
                      );
                    })}
                  <button
                    className="card newcard"
                    onClick={() => open({ type: "project" })}
                  >
                    <span className="circle">
                      <Plus />
                    </span>
                    <b>Criar projeto</b>
                    <span>Comece em branco ou use um modelo</span>
                  </button>
                </div>
                {!data.projects.length && (
                  <div className="notice">
                    <p>
                      Seu aplicativo está pronto. Crie um projeto ou carregue
                      exemplos fictícios.
                    </p>
                    <Btn onClick={() => void demo()}>
                      Experimentar com dados de demonstração
                    </Btn>
                  </div>
                )}
              </>
            )}
            {page === "detail" && project && (
              <>
                <div className="heading row between">
                  <div>
                    <span className="eyebrow">
                      {
                        {
                          event: "Evento",
                          budget: "Orçamento",
                          blank: "Projeto",
                        }[project.type]
                      }{" "}
                      · {projectItems.length} itens
                    </span>
                    <h1>{project.name}</h1>
                    <p>{project.description}</p>
                  </div>
                  <div className="row">
                    <Btn
                      onClick={() => open({ type: "project-menu", project })}
                    >
                      <MoreHorizontal /> Ações
                    </Btn>
                    <Btn primary onClick={() => open({ type: "item" })}>
                      <Plus /> Novo item
                    </Btn>
                  </div>
                </div>
                <Summary items={projectItems} payments={data.payments} />
                <div className="mininav">
                  <span className="micro">Itens e pagamentos</span>
                  <div className="row">
                    <Btn onClick={() => open({ type: "import" })}>
                      <Upload />
                      Importar
                    </Btn>
                    <Btn
                      onClick={() =>
                        void run(() =>
                          exportXlsx(project, filtered, data.payments),
                        )
                      }
                    >
                      <Download />
                      Excel
                    </Btn>
                    <Btn
                      onClick={() =>
                        void run(() =>
                          exportPdf(project, filtered, data.payments),
                        )
                      }
                    >
                      <FileText />
                      PDF
                    </Btn>
                  </div>
                </div>
                <div className="toolbar">
                  <div className="search">
                    <Search />
                    <input
                      aria-label="Buscar itens"
                      placeholder="Buscar descrição, fornecedor ou categoria…"
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                    />
                  </div>
                  <div className="seg">
                    <button
                      className={view === "table" ? "on" : ""}
                      aria-pressed={view === "table"}
                      onClick={() => {
                        setView("table");
                        setCell(null);
                      }}
                    >
                      <List />
                      Planilha
                    </button>
                    <button
                      className={view === "cards" ? "on" : ""}
                      aria-pressed={view === "cards"}
                      onClick={() => {
                        setView("cards");
                        setCell(null);
                      }}
                    >
                      <LayoutGrid />
                      Cards
                    </button>
                  </div>
                </div>
                <div className="filterbar">
                  <label>
                    Status
                    <select
                      value={filter}
                      onChange={(e) => setFilter(e.target.value)}
                    >
                      <option value="">Todos</option>
                      {Object.entries(statusNames).map(([v, n]) => (
                        <option key={v} value={v}>
                          {n}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Categoria
                    <select
                      value={cat}
                      onChange={(e) => setCat(e.target.value)}
                    >
                      <option value="">Todas</option>
                      {categories.filter(Boolean).map((c) => (
                        <option key={c}>{c}</option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Fornecedor
                    <select
                      value={supplier}
                      onChange={(e) => setSupplier(e.target.value)}
                    >
                      <option value="">Todos</option>
                      {suppliers.filter(Boolean).map((s) => (
                        <option key={s}>{s}</option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Vencimento
                    <select
                      value={due}
                      onChange={(e) => setDue(e.target.value)}
                    >
                      <option value="">Todos</option>
                      <option value="late">Em atraso</option>
                      <option value="soon">Próximos 7 dias</option>
                      <option value="none">Sem vencimento</option>
                    </select>
                  </label>
                  <label>
                    Ordenar por
                    <select
                      value={sort}
                      onChange={(e) => setSort(e.target.value)}
                    >
                      {[
                        ["description", "Descrição"],
                        ["budget", "Maior valor"],
                        ["remaining", "Maior saldo"],
                        ["due", "Vencimento"],
                        ["status", "Status"],
                      ].map(([v, l]) => (
                        <option key={v} value={v}>
                          {l}
                        </option>
                      ))}
                    </select>
                  </label>
                  {view === "cards" ? (
                    <label>
                      Agrupar
                      <select
                        value={group}
                        onChange={(e) => setGroup(e.target.value)}
                      >
                        <option value="">Sem agrupamento</option>
                        <option value="status">Status</option>
                        <option value="category">Categoria</option>
                        <option value="supplier">Fornecedor</option>
                        <option value="due">Vencimento</option>
                      </select>
                    </label>
                  ) : (
                    <Btn onClick={() => open({ type: "columns" })}>
                      <Columns3 />
                      Colunas
                    </Btn>
                  )}
                  {(query || filter || cat || supplier || due) && (
                    <Btn onClick={clearFilters}>Limpar filtros</Btn>
                  )}
                  <span className="micro">
                    {filtered.length} de {projectItems.length} itens
                  </span>
                </div>
                {view === "table" ? (
                  <>
                    <div className="sheetbar">
                      <div>
                        <b>{sheet ? "Modo planilha" : "Modo de consulta"}</b>
                        <span>
                          {sheet
                            ? "Edite as células · Tab: próxima coluna · Enter: próxima linha · Esc: cancelar"
                            : "1 clique na linha: editar item · 2 cliques: editar células"}
                        </span>
                      </div>
                      <Btn
                        primary={sheet}
                        onClick={() => {
                          if (cell) void finishCell();
                          setSheet(!sheet);
                        }}
                      >
                        {sheet ? <Check /> : <List />}
                        {sheet
                          ? "Concluir edição em células"
                          : "Editar em células"}
                      </Btn>
                    </div>
                    <div
                      className={"tablebox " + (sheet ? "sheetmode" : "")}
                      role="region"
                      aria-label="Planilha de itens"
                      tabIndex={0}
                    >
                      <table>
                        <caption>
                          Itens do projeto. Clique simples abre a edição. Clique
                          duplo ativa as células editáveis.
                        </caption>
                        <thead>
                          <tr>
                            {columns.map((c) => (
                              <th
                                scope="col"
                                key={c.id}
                                className={
                                  [
                                    "budgetCents",
                                    "unitCents",
                                    "paid",
                                    "remaining",
                                    "quantity",
                                  ].includes(c.id)
                                    ? "numeric"
                                    : ""
                                }
                              >
                                {c.name}
                                {sheet && !editable(c.id) && (
                                  <small className="computedlabel">
                                    Calculado
                                  </small>
                                )}
                              </th>
                            ))}
                            <th scope="col">Pagamentos</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filtered.map((i) => (
                            <tr
                              key={i.id}
                              data-item={i.id}
                              tabIndex={sheet ? -1 : 0}
                              onClick={(e) => rowClick(e, i)}
                              onDoubleClick={(e) => rowDouble(e, i)}
                              onKeyDown={(e) => {
                                if (
                                  e.target === e.currentTarget &&
                                  e.key === "Enter"
                                )
                                  open({ type: "item", item: i });
                              }}
                              aria-label={"Editar " + i.description}
                            >
                              {columns.map((c) => (
                                <td
                                  key={c.id}
                                  data-field={c.id}
                                  tabIndex={sheet ? 0 : undefined}
                                  className={
                                    (sheet && editable(c.id)
                                      ? "editablecell "
                                      : "") +
                                    (cell?.id === i.id && cell.field === c.id
                                      ? "editingcell "
                                      : "") +
                                    ([
                                      "budgetCents",
                                      "unitCents",
                                      "paid",
                                      "remaining",
                                      "quantity",
                                    ].includes(c.id)
                                      ? "numeric"
                                      : "")
                                  }
                                  onKeyDown={(e) => {
                                    if (
                                      e.target === e.currentTarget &&
                                      ["Enter", "F2"].includes(e.key) &&
                                      editable(c.id)
                                    ) {
                                      e.preventDefault();
                                      e.stopPropagation();
                                      setSheet(true);
                                      setCell({
                                        id: i.id,
                                        field: c.id,
                                        value: rawCell(i, c.id),
                                      });
                                    }
                                  }}
                                >
                                  {renderCell(i, c)}
                                </td>
                              ))}
                              <td
                                className="paymentcell"
                                onClick={(e) => e.stopPropagation()}
                                onDoubleClick={(e) => e.stopPropagation()}
                              >
                                {paymentButton(i)}
                                {data.payments.some(
                                  (p) => p.itemId === i.id,
                                ) && (
                                  <button
                                    className="historylink"
                                    onClick={() =>
                                      open({ type: "item", item: i })
                                    }
                                  >
                                    Ver pagamentos
                                  </button>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                        <tfoot>
                          <tr>
                            {columns.map((c, n) => (
                              <td key={c.id} className="numeric">
                                {n === 0
                                  ? "Total ativo filtrado"
                                  : c.id === "budgetCents"
                                    ? money(
                                        totals(filtered, data.payments).budget,
                                      )
                                    : c.id === "paid"
                                      ? money(
                                          totals(filtered, data.payments).paid,
                                        )
                                      : c.id === "remaining"
                                        ? money(
                                            totals(filtered, data.payments)
                                              .remaining,
                                          )
                                        : ""}
                              </td>
                            ))}
                            <td>{filtered.length} itens</td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                    <div className="tablebottom">
                      <span className="micro">
                        Pago, saldo e último método são calculados. Alterações
                        financeiras recalculam os totais.
                      </span>
                      <Btn onClick={() => open({ type: "new-column" })}>
                        <Plus />
                        Adicionar coluna
                      </Btn>
                    </div>
                  </>
                ) : group ? (
                  <>
                    {[
                      ...new Set(
                        filtered.map((i) =>
                          group === "status"
                            ? statusNames[status(i, data.payments)]
                            : group === "due"
                              ? brDate(i.due)
                              : String(
                                  i[group as keyof Item] || "Sem informação",
                                ),
                        ),
                      ),
                    ].map((g) => (
                      <section key={g}>
                        <h3 style={{ margin: "24px 0 14px" }}>{g}</h3>
                        <div className="grid">
                          {filtered
                            .filter(
                              (i) =>
                                (group === "status"
                                  ? statusNames[status(i, data.payments)]
                                  : group === "due"
                                    ? brDate(i.due)
                                    : String(
                                        i[group as keyof Item] ||
                                          "Sem informação",
                                      )) === g,
                            )
                            .map(itemCard)}
                        </div>
                      </section>
                    ))}
                  </>
                ) : (
                  <div className="grid">{filtered.map(itemCard)}</div>
                )}
                {!filtered.length && (
                  <div className="empty">
                    Nenhum item encontrado. Adicione um item ou ajuste os
                    filtros.
                  </div>
                )}
              </>
            )}
            {page === "payments" && (
              <>
                <span className="eyebrow">Histórico consolidado</span>
                <h1>Pagamentos</h1>
                <p>Abra um pagamento para visualizar o comprovante.</p>
                <div className="tablebox" style={{ marginTop: 24 }}>
                  <table>
                    <thead>
                      <tr>
                        {[
                          "Data",
                          "Projeto",
                          "Item",
                          "Método",
                          "Valor",
                          "Comprovante",
                          "Ação",
                        ].map((n) => (
                          <th scope="col" key={n}>
                            {n}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {[...data.payments]
                        .sort((a, b) => b.date.localeCompare(a.date))
                        .map((p) => {
                          let i = data.items.find((x) => x.id === p.itemId)!;
                          return (
                            <tr
                              key={p.id}
                              onClick={() =>
                                open({ type: "payment-detail", payment: p })
                              }
                            >
                              <td>{brDate(p.date)}</td>
                              <td>
                                {
                                  data.projects.find(
                                    (x) => x.id === i?.projectId,
                                  )?.name
                                }
                              </td>
                              <td>
                                {i?.description || "Item excluído — revisar"}
                              </td>
                              <td>{p.method}</td>
                              <td className="numeric">
                                <b>{money(p.amountCents)}</b>
                              </td>
                              <td>
                                {p.receipt
                                  ? "📎 " + p.receipt.name
                                  : "Sem comprovante"}
                              </td>
                              <td>
                                <Btn
                                  onClick={() =>
                                    open({ type: "payment-detail", payment: p })
                                  }
                                >
                                  Abrir pagamento
                                </Btn>
                              </td>
                            </tr>
                          );
                        })}
                    </tbody>
                  </table>
                </div>
              </>
            )}
            {page === "overview" && (
              <>
                <span className="eyebrow">Todos os seus projetos</span>
                <h1>Visão geral</h1>
                <Summary
                  items={data.items.filter((i) =>
                    data.projects.some((p) => p.id === i.projectId),
                  )}
                  payments={data.payments}
                />
                <div className="twocol">
                  <section className="panel">
                    <h2>Quitação por projeto</h2>
                    {data.projects.map((p) => {
                      let t = totals(
                        data.items.filter((i) => i.projectId === p.id),
                        data.payments,
                      );
                      return (
                        <div className="chartrow" key={p.id}>
                          <div className="row between">
                            <b>{p.name}</b>
                            <span>{t.percent}%</span>
                          </div>
                          <Progress percent={t.percent} />
                          <p className="micro">
                            {money(t.paid)} de {money(t.budget)}
                          </p>
                        </div>
                      );
                    })}
                  </section>
                  <section className="panel">
                    <h2>Precisa de atenção</h2>
                    {overdue.map((i) => (
                      <button
                        key={i.id}
                        className="paymenthistoryrow"
                        onClick={() => {
                          enter(
                            data.projects.find((p) => p.id === i.projectId)!,
                          );
                          open({ type: "item", item: i });
                        }}
                      >
                        <span>
                          {i.description}
                          <small>{brDate(i.due)}</small>
                        </span>
                        <b className="danger">
                          {money(remaining(i, data.payments))}
                        </b>
                      </button>
                    ))}
                    {!overdue.length && <p>Nenhum vencimento em atraso.</p>}
                  </section>
                </div>
              </>
            )}
            {page === "settings" && (
              <>
                <span className="eyebrow">Preferências</span>
                <h1>Configurações</h1>
                <p>Personalize o aplicativo e conecte seus dispositivos.</p>
                <section className="panel">
                  <h2>Tema do aplicativo</h2>
                  <div className="themechoices">
                    {[
                      ["light", "Azul e branco"],
                      ["dark", "Preto e azul"],
                      ["system", "Seguir o sistema"],
                    ].map(([v, l]) => (
                      <button
                        key={v}
                        className={"themechoice " + (theme === v ? "on" : "")}
                        aria-pressed={theme === v}
                        onClick={() => setTheme(v)}
                      >
                        <span className={"swatch " + v} />
                        {l}
                      </button>
                    ))}
                  </div>
                </section>
                <div className="twocol">
                  <section className="panel">
                    <h2>Formato regional</h2>
                    <div className="listcard">
                      Moeda padrão <b>BRL · R$</b>
                    </div>
                    <div className="listcard">
                      Datas <b>DD/MM/AAAA</b>
                    </div>
                    <p>
                      Enter abre a linha em foco. F2 em uma célula ativa a
                      edição. Tab e Enter avançam; Esc cancela a célula.
                    </p>
                  </section>
                  <section className="panel">
                    <h2>Aplicativo e conexões</h2>
                    <div className="form">
                      <Btn onClick={() => open({ type: "install" })}>
                        <Monitor />
                        Instalar aplicativo
                      </Btn>
                      <Btn onClick={() => open({ type: "updates" })}>
                        <RefreshCw />
                        Verificar atualizações
                      </Btn>
                      <Btn onClick={() => open({ type: "sync" })}>
                        <Link2 />
                        Sincronização entre computadores
                      </Btn>
                      <Btn onClick={() => go("storage")}>
                        <ShieldCheck />
                        Dados e backup
                      </Btn>
                    </div>
                  </section>
                </div>
              </>
            )}
            {page === "storage" && (
              <>
                <span className="eyebrow">Armazenamento e privacidade</span>
                <h1>Dados e backup</h1>
                <p>
                  Seus dados ficam no dispositivo, separados do código do
                  aplicativo.
                </p>
                <div className="twocol">
                  <section className="panel">
                    <h2>Banco local</h2>
                    <dl className="datafacts">
                      <dt>Tecnologia</dt>
                      <dd>IndexedDB · gestao-orcamentos · versão 1</dd>
                      <dt>Conteúdo</dt>
                      <dd>
                        Projetos, itens, pagamentos, comprovantes e histórico de
                        alterações.
                      </dd>
                      <dt>Quando salva</dt>
                      <dd>
                        Ao confirmar uma edição ou pagamento; na planilha, ao
                        sair da célula.
                      </dd>
                      <dt>Atualizações</dt>
                      <dd>
                        Atualizam os arquivos do aplicativo, preservando o banco
                        local.
                      </dd>
                      <dt>Sincronização</dt>
                      <dd>
                        Somente com dispositivos pareados e confirmados. Dados
                        não são enviados ao GitHub.
                      </dd>
                      <dt>Persistência</dt>
                      <dd>
                        {persistent
                          ? "Proteção contra remoção automática concedida."
                          : "Ainda não concedida pelo navegador."}{" "}
                        Limpar dados do site apaga o banco. Mantenha backups.
                      </dd>
                    </dl>
                    <Btn onClick={() => void run(requestPersistent)}>
                      <ShieldCheck />
                      Solicitar armazenamento persistente
                    </Btn>
                  </section>
                  <section className="panel">
                    <h2>Backup completo</h2>
                    <p>
                      O arquivo .gorc inclui comprovantes e histórico de
                      alterações. Guarde-o em local seguro.
                    </p>
                    <div className="form">
                      <Btn primary onClick={backup}>
                        <Download />
                        Exportar backup completo
                      </Btn>
                      <label>
                        Restaurar backup (.gorc)
                        <input
                          type="file"
                          accept=".gorc,.json"
                          onChange={(e) => {
                            let f = e.target.files?.[0];
                            if (
                              f &&
                              confirm(
                                "Restaurar este backup e substituir os registros atuais? A restauração será sincronizada. Exporte um backup antes de continuar.",
                              )
                            )
                              void run(async () => {
                                await importBackup(f, true);
                                notify("Backup restaurado.");
                              });
                          }}
                        />
                      </label>
                      <label>
                        Mesclar backup / histórico
                        <input
                          type="file"
                          accept=".gorc,.json"
                          onChange={(e) => {
                            let f = e.target.files?.[0];
                            if (
                              f &&
                              confirm(
                                "Mesclar os dados deste backup? Conflitos serão apresentados para revisão.",
                              )
                            )
                              void run(async () => {
                                await importBackup(f, false);
                                notify("Backup mesclado.");
                              });
                          }}
                        />
                      </label>
                      <label>
                        Importar backup do protótipo antigo
                        <input
                          type="file"
                          accept=".json"
                          onChange={(e) => {
                            let f = e.target.files?.[0];
                            if (
                              f &&
                              confirm(
                                "Importar projetos e pagamentos do protótipo? Registros com o mesmo ID serão atualizados.",
                              )
                            )
                              void run(async () => {
                                await importLegacy(f);
                                notify("Dados do protótipo importados.");
                              });
                          }}
                        />
                      </label>
                    </div>
                  </section>
                </div>
                <div className="notice">
                  O banco é local ao navegador e ao endereço do aplicativo.
                  Trocar de computador, perfil ou endereço exige sincronizar ou
                  importar um backup. Os dados não são criptografados em
                  repouso; proteja sua conta do sistema e seus backups.
                </div>
              </>
            )}
            {error && !modal && (
              <div className="warningbanner" role="alert">
                {error}
                <button onClick={() => setError("")} aria-label="Fechar erro">
                  <X />
                </button>
              </div>
            )}
          </div>
        </main>
      </div>
      {modal && (
        <div
          className="overlay"
          onClick={(e) => {
            if (e.target === e.currentTarget) close();
          }}
        >
          <div
            ref={modalRef}
            className={
              "modal " + (modal.type === "item" ? "item-edit-modal" : "")
            }
            role="dialog"
            aria-modal="true"
            aria-labelledby="dialog-title"
            onKeyDown={(e) => {
              if (e.key === "Escape") {
                e.stopPropagation();
                close();
              }
              if (e.key === "Tab") {
                let all = [
                  ...(modalRef.current?.querySelectorAll<HTMLElement>(
                    "button:not(:disabled),input:not(:disabled),select:not(:disabled),textarea:not(:disabled),a[href],summary",
                  ) || []),
                ].filter((x) => x.getClientRects().length);
                if (e.shiftKey && document.activeElement === all[0]) {
                  e.preventDefault();
                  all.at(-1)?.focus();
                } else if (
                  !e.shiftKey &&
                  document.activeElement === all.at(-1)
                ) {
                  e.preventDefault();
                  all[0]?.focus();
                }
              }
            }}
          >
            <div className="row between">
              <h2 id="dialog-title" tabIndex={-1}>
                {
                  {
                    project:
                      modal.type === "project" && modal.project
                        ? "Editar projeto"
                        : "Novo projeto",
                    item:
                      modal.type === "item" && modal.item
                        ? "Editar item"
                        : "Novo item",
                    payment:
                      modal.type === "payment" && modal.payment
                        ? "Editar pagamento"
                        : "Registrar pagamento",
                    "payment-detail": "Detalhe do pagamento",
                    columns: "Organizar colunas",
                    "new-column": "Adicionar coluna",
                    sync: "Sincronização entre dispositivos",
                    install: "Instalar como aplicativo",
                    updates: "Atualizações",
                    import: "Importar Excel / CSV",
                    conflicts: "Resolver conflitos",
                    "project-menu": "Ações do projeto",
                  }[modal.type]
                }
              </h2>
              <button aria-label="Fechar" onClick={close}>
                <X />
              </button>
            </div>
            {error && (
              <p className="formerror" role="alert">
                {error}
              </p>
            )}
            {modal.type === "project" && (
              <form
                className="form"
                onChange={() => setDirty(true)}
                onSubmit={(e) => void saveProject(e, modal.project)}
              >
                <label>
                  Nome do projeto *
                  <input
                    name="name"
                    required
                    maxLength={200}
                    defaultValue={modal.project?.name}
                  />
                </label>
                <label>
                  Descrição
                  <textarea
                    name="description"
                    defaultValue={modal.project?.description}
                  />
                </label>
                <div className="row">
                  <label>
                    Modelo
                    <select
                      name="type"
                      defaultValue={modal.project?.type || "blank"}
                    >
                      <option value="blank">Em branco</option>
                      <option value="budget">Orçamento / Despesas</option>
                      <option value="event">Evento</option>
                    </select>
                  </label>
                  <label>
                    Cor de capa
                    <input
                      type="color"
                      name="color"
                      defaultValue={modal.project?.color || "#0969cf"}
                    />
                  </label>
                </div>
                <label>
                  Visualização inicial
                  <select
                    name="view"
                    defaultValue={modal.project?.view || "table"}
                  >
                    <option value="table">Planilha</option>
                    <option value="cards">Cards</option>
                  </select>
                </label>
                <p className="micro">
                  O modelo Evento inclui sugestões editáveis. Você pode
                  preencher fornecedores e valores depois.
                </p>
                <div className="actions">
                  <Btn onClick={close}>Cancelar</Btn>
                  <Btn primary type="submit" disabled={busy}>
                    <Save />
                    Salvar projeto
                  </Btn>
                </div>
              </form>
            )}
            {modal.type === "project-menu" && (
              <>
                <h3>{modal.project.name}</h3>
                <div className="form">
                  <Btn
                    onClick={() => {
                      enter(modal.project);
                      setModal(null);
                    }}
                  >
                    <Folder />
                    Abrir projeto
                  </Btn>
                  <Btn
                    onClick={() =>
                      open({ type: "project", project: modal.project })
                    }
                  >
                    <Settings />
                    Editar projeto
                  </Btn>
                  <Btn
                    onClick={() => void duplicate(modal.project)}
                    disabled={busy}
                  >
                    <Copy />
                    Duplicar com pagamentos
                  </Btn>
                  <Btn
                    onClick={() => {
                      backup();
                      notify("Backup completo exportado.");
                    }}
                  >
                    <Download />
                    Exportar backup completo
                  </Btn>
                  <Btn
                    danger
                    onClick={() => void deleteProject(modal.project)}
                    disabled={busy}
                  >
                    <Trash2 />
                    Excluir projeto
                  </Btn>
                </div>
              </>
            )}
            {modal.type === "item" && (
              <>
                <p>
                  Comece com descrição e fornecedor. Complete os demais dados
                  depois.
                </p>
                {modal.item && (
                  <section className="item-payment-block">
                    <div className="itemsummary">
                      <div>
                        <span>Orçado</span>
                        <b>
                          {budget(modal.item)
                            ? money(budget(modal.item))
                            : "A definir"}
                        </b>
                      </div>
                      <div>
                        <span>Pago</span>
                        <b>{money(paid(modal.item, data.payments))}</b>
                      </div>
                      <div>
                        <span>Restante</span>
                        <b>{money(remaining(modal.item, data.payments))}</b>
                      </div>
                    </div>
                    <Btn
                      primary
                      className="payment-main"
                      onClick={() =>
                        open({ type: "payment", item: modal.item! })
                      }
                    >
                      <Wallet />
                      Registrar pagamento
                    </Btn>
                    {history(modal.item)}
                  </section>
                )}
                <form
                  className="form"
                  onChange={() => setDirty(true)}
                  onSubmit={(e) => void saveItem(e, modal.item)}
                >
                  <label>
                    Descrição *
                    <input
                      name="description"
                      required
                      maxLength={200}
                      defaultValue={modal.item?.description}
                    />
                  </label>
                  <label>
                    Fornecedor *
                    <input
                      name="supplier"
                      required
                      maxLength={200}
                      list="suppliers"
                      defaultValue={modal.item?.supplier}
                      placeholder="Selecione ou digite um novo fornecedor"
                    />
                  </label>
                  <details open={!!modal.item}>
                    <summary>
                      Valores, categoria e vencimento <small>Opcional</small>
                    </summary>
                    <div className="form">
                      <label>
                        Categoria
                        <input
                          name="category"
                          list="categories"
                          defaultValue={modal.item?.category}
                        />
                      </label>
                      <div className="row">
                        <label>
                          Quantidade
                          <input
                            name="quantity"
                            type="number"
                            min="0.001"
                            step="any"
                            defaultValue={modal.item?.quantity}
                            placeholder="1 se não informado"
                          />
                        </label>
                        <label>
                          Valor unitário (R$)
                          <input
                            name="unit"
                            inputMode="decimal"
                            defaultValue={
                              modal.item?.unitCents
                                ? String(modal.item.unitCents / 100)
                                : ""
                            }
                            placeholder="A definir"
                          />
                        </label>
                      </div>
                      <label>
                        Valor orçado manual (R$)
                        <input
                          name="budget"
                          inputMode="decimal"
                          defaultValue={
                            modal.item?.budgetCents == null
                              ? ""
                              : String(modal.item.budgetCents / 100)
                          }
                          placeholder="Opcional; substitui quantidade × valor unitário"
                        />
                      </label>
                      <div className="row">
                        <label>
                          Vencimento
                          <input
                            type="date"
                            name="due"
                            defaultValue={modal.item?.due}
                          />
                        </label>
                        <label>
                          Situação
                          <select
                            name="status"
                            defaultValue={modal.item?.status || "planned"}
                          >
                            {[
                              "planned",
                              "quoted",
                              "confirmed",
                              "cancelled",
                            ].map((s) => (
                              <option key={s} value={s}>
                                {statusNames[s]}
                              </option>
                            ))}
                          </select>
                        </label>
                      </div>
                      <label>
                        Observações
                        <textarea
                          name="notes"
                          defaultValue={modal.item?.notes}
                        />
                      </label>
                    </div>
                  </details>
                  {project?.columns.length ? (
                    <details open>
                      <summary>Colunas personalizadas</summary>
                      <div className="form">
                        {project.columns.map((c) => (
                          <label key={c.id}>
                            {c.name}
                            <input
                              name={"custom:" + c.id}
                              type={
                                c.type === "date"
                                  ? "date"
                                  : c.type === "number"
                                    ? "number"
                                    : "text"
                              }
                              step={c.type === "number" ? "any" : undefined}
                              list={
                                c.type === "choice"
                                  ? "custom-" + c.id
                                  : undefined
                              }
                              defaultValue={modal.item?.custom[c.id]}
                            />
                          </label>
                        ))}
                      </div>
                    </details>
                  ) : null}
                  <div className="actions">
                    {modal.item && (
                      <Btn
                        danger
                        onClick={() => void deleteItem(modal.item!)}
                        disabled={busy}
                      >
                        <Trash2 />
                        Excluir
                      </Btn>
                    )}
                    <Btn onClick={close}>Cancelar</Btn>
                    <Btn primary type="submit" disabled={busy}>
                      <Check />
                      Salvar item
                    </Btn>
                  </div>
                </form>
              </>
            )}
            {modal.type === "payment" && (
              <>
                <p>
                  {modal.item.description} · {modal.item.supplier}
                </p>
                <div className="panel row between">
                  <span>Saldo atual</span>
                  <b>{money(remaining(modal.item, data.payments))}</b>
                </div>
                <form
                  className="form"
                  onChange={() => setDirty(true)}
                  onSubmit={(e) =>
                    void savePayment(e, modal.item, modal.payment)
                  }
                >
                  <div className="row">
                    <label>
                      Valor (R$) *
                      <input
                        name="amount"
                        inputMode="decimal"
                        required
                        defaultValue={String(
                          (modal.payment?.amountCents ??
                            Math.max(0, remaining(modal.item, data.payments))) /
                            100,
                        )}
                      />
                    </label>
                    <label>
                      Data *
                      <input
                        type="date"
                        name="date"
                        required
                        defaultValue={modal.payment?.date || today()}
                      />
                    </label>
                  </div>
                  <label>
                    Método *
                    <input
                      name="method"
                      required
                      list="methods"
                      defaultValue={modal.payment?.method || "Pix"}
                      placeholder="Selecione ou digite"
                    />
                  </label>
                  <label>
                    Comprovante — imagem ou PDF
                    <input
                      type="file"
                      name="receipt"
                      accept="image/png,image/jpeg,image/webp,image/gif,application/pdf"
                    />
                    <span className="micro">
                      Até 5 MB. O arquivo será salvo com o pagamento, neste
                      dispositivo.
                    </span>
                  </label>
                  {modal.payment?.receipt && (
                    <>
                      <p className="micro">
                        Atual: {modal.payment.receipt.name}
                      </p>
                      <label className="checklabel">
                        <input type="checkbox" name="removeReceipt" />
                        Remover comprovante atual
                      </label>
                    </>
                  )}
                  <label>
                    Observações
                    <textarea
                      name="notes"
                      defaultValue={modal.payment?.notes}
                    />
                  </label>
                  <div className="actions">
                    <Btn
                      onClick={() => open({ type: "item", item: modal.item })}
                    >
                      Voltar ao item
                    </Btn>
                    <Btn primary type="submit" disabled={busy}>
                      <Check />
                      Confirmar pagamento
                    </Btn>
                  </div>
                </form>
              </>
            )}
            {modal.type === "payment-detail" && (
              <>
                <p>
                  {
                    data.items.find((i) => i.id === modal.payment.itemId)
                      ?.description
                  }
                </p>
                <div className="payment-detail-summary">
                  <strong>{money(modal.payment.amountCents)}</strong>
                  <span>
                    {brDate(modal.payment.date)} · {modal.payment.method}
                  </span>
                </div>
                <p>{modal.payment.notes || "Sem observações."}</p>
                <h3 style={{ marginTop: 24 }}>Comprovante</h3>
                <Receipt payment={modal.payment} />
                <div className="actions">
                  <Btn
                    disabled={
                      !data.items.some((i) => i.id === modal.payment.itemId)
                    }
                    onClick={() =>
                      open({
                        type: "item",
                        item: data.items.find(
                          (i) => i.id === modal.payment.itemId,
                        ),
                      })
                    }
                  >
                    Voltar ao item
                  </Btn>
                  <Btn
                    danger
                    onClick={() => void removePayment(modal.payment)}
                    disabled={busy}
                  >
                    Excluir pagamento
                  </Btn>
                  <Btn
                    primary
                    disabled={
                      !data.items.some((i) => i.id === modal.payment.itemId)
                    }
                    onClick={() =>
                      open({
                        type: "payment",
                        item: data.items.find(
                          (i) => i.id === modal.payment.itemId,
                        )!,
                        payment: modal.payment,
                      })
                    }
                  >
                    Editar pagamento
                  </Btn>
                </div>
              </>
            )}
            {modal.type === "columns" && (
              <>
                <p>
                  Colunas personalizadas começam vazias nos registros
                  existentes.
                </p>
                <Btn primary onClick={() => open({ type: "new-column" })}>
                  <Plus />
                  Adicionar coluna
                </Btn>
                <div className="form">
                  {sortedColumns.map((c, n) => (
                    <div className="columnrow" key={c.id}>
                      <label className="checklabel">
                        <input
                          type="checkbox"
                          checked={columns.some((x) => x.id === c.id)}
                          disabled={c.id === "description"}
                          onChange={(e) => {
                            let custom = project?.columns.some(
                                (x) => x.id === c.id,
                              ),
                              v = e.target.checked
                                ? custom
                                  ? visible.filter((x) => x !== "!" + c.id)
                                  : [...visible, c.id]
                                : custom
                                  ? [...visible, "!" + c.id]
                                  : visible.filter((x) => x !== c.id);
                            void persistColumns(v, order);
                          }}
                        />
                        {c.name}
                      </label>
                      <div className="row">
                        <Btn
                          title={"Mover " + c.name + " para cima"}
                          disabled={n === 0}
                          onClick={() => {
                            let o = sortedColumns.map((x) => x.id);
                            [o[n], o[n - 1]] = [o[n - 1], o[n]];
                            void persistColumns(visible, o);
                          }}
                        >
                          <ChevronUp />
                        </Btn>
                        <Btn
                          title={"Mover " + c.name + " para baixo"}
                          disabled={n === sortedColumns.length - 1}
                          onClick={() => {
                            let o = sortedColumns.map((x) => x.id);
                            [o[n], o[n + 1]] = [o[n + 1], o[n]];
                            void persistColumns(visible, o);
                          }}
                        >
                          <ChevronDown />
                        </Btn>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="actions">
                  <Btn primary onClick={close}>
                    Concluir
                  </Btn>
                </div>
              </>
            )}
            {modal.type === "new-column" && (
              <form
                className="form"
                onChange={() => setDirty(true)}
                onSubmit={(e) => void createColumn(e)}
              >
                <p>
                  A nova coluna ficará vazia em todos os itens deste projeto e
                  não alterará os cálculos financeiros.
                </p>
                <label>
                  Nome da coluna *<input name="name" required maxLength={100} />
                </label>
                <label>
                  Tipo
                  <select name="type">
                    <option value="text">Texto</option>
                    <option value="number">Número</option>
                    <option value="date">Data</option>
                    <option value="choice">
                      Lista de opções — aceita novos valores
                    </option>
                  </select>
                </label>
                <div className="actions">
                  <Btn onClick={() => open({ type: "columns" })}>Voltar</Btn>
                  <Btn primary type="submit" disabled={busy}>
                    Criar coluna
                  </Btn>
                </div>
              </form>
            )}
            {modal.type === "install" && (
              <>
                <div className="installhero">
                  <Monitor />
                  <h3>
                    {pwaState.installed
                      ? "Aplicativo instalado"
                      : "Seu orçamento em uma janela própria"}
                  </h3>
                  <p>
                    Depois de instalar, abra pelo menu Iniciar, Dock ou Tela de
                    Início. Após o primeiro carregamento completo, funciona
                    offline.
                  </p>
                </div>
                <div className="notice">
                  A instalação precisa de uma ação sua. Um site não pode se
                  instalar ou abrir automaticamente uma janela de aplicativo sem
                  autorização.
                </div>
                <div className="notice">
                  <b>Windows 10/11 · 64 bits</b>
                  <p>
                    O instalador cria os atalhos e abre esta PWA usando Edge ou
                    Chrome. Requer internet no primeiro acesso.
                  </p>
                  <a
                    className="receipt-download"
                    href="./downloads/Gestao-de-Orcamentos-Windows.zip"
                    download
                  >
                    <Download />
                    Baixar instalador Windows (.zip)
                  </a>
                  <p className="micro">
                    Executável sem assinatura digital. Compilado para Windows,
                    mas não executado em Windows neste ambiente.
                  </p>
                </div>
                <div className="form">
                  <Btn primary onClick={() => void run(install)}>
                    <Download />
                    {pwaState.installed
                      ? "Instruções de instalação"
                      : "Instalar aplicativo"}
                  </Btn>
                  <p className="micro">
                    Windows: Edge/Chrome → menu → Aplicativos / Instalar.
                    iPhone: Safari → Compartilhar → Adicionar à Tela de Início →
                    Abrir como App.
                  </p>
                  <Btn onClick={() => void run(requestPersistent)}>
                    <ShieldCheck />
                    Proteger armazenamento offline
                  </Btn>
                </div>
              </>
            )}
            {modal.type === "updates" && (
              <>
                <div className="update-current">
                  <span>Versão instalada</span>
                  <b>1.0.0</b>
                </div>
                <p>
                  As novas versões são publicadas no mesmo endereço do
                  aplicativo. O botão abaixo consulta o serviço de atualização
                  sem enviar dados financeiros.
                </p>
                <div className="notice">
                  {pwaState.status ||
                    (pwaState.update
                      ? "Uma atualização está pronta."
                      : "Você pode verificar uma nova publicação a qualquer momento.")}
                </div>
                <div className="actions">
                  <Btn onClick={() => void checkUpdate()}>
                    <RefreshCw />
                    Verificar agora
                  </Btn>
                  {pwaState.update && (
                    <Btn
                      primary
                      onClick={() => {
                        if (dirty || cell) {
                          notify("Salve a edição antes de atualizar.");
                          return;
                        }
                        if (
                          confirm(
                            "Aplicar a atualização e reabrir o aplicativo? Os dados salvos serão preservados.",
                          )
                        )
                          applyUpdate();
                      }}
                    >
                      Atualizar e reabrir
                    </Btn>
                  )}
                </div>
                <p className="micro">
                  O fluxo de publicação pelo GitHub está incluído no
                  código-fonte. A PWA aplica o pacote publicado pelo service
                  worker; não baixa instaladores .exe.
                </p>
              </>
            )}
            {modal.type === "sync" && (
              <>
                <p>
                  Conecte dois dispositivos abertos. Os dados ficam locais e as
                  alterações são trocadas por um canal criptografado.
                </p>
                <div className="notice">
                  <b>Como parear:</b> no computador A, crie o convite e envie o
                  código ao B. No B, aceite o convite e devolva o código de
                  resposta. No A, aplique a resposta. Compare a chave curta nos
                  dois e confirme a sincronização em ambos. Todos os projetos e
                  comprovantes serão compartilhados somente após essas
                  confirmações.
                </div>
                <div className="rowtools" style={{ marginTop: 18 }}>
                  <Btn
                    primary
                    disabled={busy}
                    onClick={() =>
                      void run(async () => {
                        let r = await sync.invite();
                        setPairOutput(r.code);
                        setPairId(r.id);
                        notify(
                          "Convite criado. Envie o código ao outro dispositivo.",
                        );
                      })
                    }
                  >
                    <Plus />
                    Criar convite
                  </Btn>
                  <Btn
                    disabled={busy || !pairInput.trim()}
                    onClick={() =>
                      void run(async () => {
                        let r = await sync.accept(pairInput);
                        setPairOutput(r.code);
                        setPairId(r.id);
                        notify(
                          "Resposta criada. Devolva ao computador que convidou.",
                        );
                      })
                    }
                  >
                    Aceitar convite
                  </Btn>
                  <Btn
                    disabled={busy || !pairInput.trim()}
                    onClick={() =>
                      void run(async () => {
                        await sync.complete(pairInput);
                        notify(
                          "Resposta aplicada. Confirme a chave nos dois computadores.",
                        );
                      })
                    }
                  >
                    Aplicar resposta
                  </Btn>
                </div>
                <label className="form">
                  Código recebido
                  <textarea
                    value={pairInput}
                    onChange={(e) => setPairInput(e.target.value)}
                    placeholder="Cole o convite ou a resposta"
                  />
                </label>
                {pairOutput && (
                  <label className="form">
                    Código para enviar
                    <textarea readOnly value={pairOutput} />
                    <Btn
                      onClick={() =>
                        void run(async () => {
                          await navigator.clipboard.writeText(pairOutput);
                          notify("Código copiado.");
                        })
                      }
                    >
                      <Copy />
                      Copiar código
                    </Btn>
                  </label>
                )}
                {[...sync.peers.values()].map((p) => (
                  <div className="peer-card" key={p.view.id}>
                    <div className="row between">
                      <h3>{p.view.label}</h3>
                      <span className="tag">{p.view.state}</span>
                    </div>
                    <p>
                      Chave de conferência: <b>{p.view.code}</b>
                    </p>
                    <p className="micro">
                      {p.view.remoteApproved
                        ? "Outro dispositivo confirmou."
                        : "Aguardando confirmação do outro dispositivo."}
                    </p>
                    {p.view.error && <p className="danger">{p.view.error}</p>}
                    <div className="rowtools">
                      <Btn
                        primary
                        disabled={
                          p.view.approved || p.dc?.readyState !== "open"
                        }
                        onClick={() => {
                          if (
                            confirm(
                              "A chave coincide? Compartilhar todos os projetos, pagamentos e comprovantes com este dispositivo?",
                            )
                          )
                            sync.approve(p.view.id);
                        }}
                      >
                        <ShieldCheck />
                        {p.view.approved
                          ? "Autorizado"
                          : "Confirmar e sincronizar"}
                      </Btn>
                      <Btn danger onClick={() => sync.disconnect(p.view.id)}>
                        Desconectar
                      </Btn>
                    </div>
                  </div>
                ))}
                <details style={{ marginTop: 22 }}>
                  <summary>Conexão pela internet / rede avançada</summary>
                  <p className="micro">
                    Sem configuração adicional, a conexão direta funciona quando
                    a rede permite, especialmente na mesma rede local. Pela
                    internet, pode ser necessário STUN ou TURN. O serviço abaixo
                    é de sua escolha; as credenciais ficam neste dispositivo. Ao
                    fechar os aplicativos, refaça o pareamento para reconectar.
                  </p>
                  <form
                    className="form"
                    onSubmit={(e) => {
                      let f = eventForm(e);
                      void run(async () => {
                        await sync.configureNetwork(
                          String(f.url),
                          String(f.username),
                          String(f.password),
                        );
                        notify("Configuração salva. Vale para novos convites.");
                      });
                    }}
                  >
                    <label>
                      Endereço STUN/TURN
                      <input name="url" placeholder="turns:seu-servidor:5349" />
                    </label>
                    <label>
                      Usuário TURN
                      <input name="username" autoComplete="off" />
                    </label>
                    <label>
                      Senha TURN
                      <input
                        name="password"
                        type="password"
                        autoComplete="off"
                      />
                    </label>
                    <Btn type="submit" disabled={busy}>
                      Salvar configuração de rede
                    </Btn>
                  </form>
                </details>
                <p className="micro" style={{ marginTop: 14 }}>
                  Sem servidor central para os dados. É necessário que os
                  dispositivos estejam abertos e conectados ao mesmo tempo. Uma
                  conexão ativa retransmite alterações para os demais pares
                  autorizados.
                </p>
              </>
            )}
            {modal.type === "conflicts" && (
              <>
                <p>
                  Duas versões foram alteradas sem comunicação. Escolha a versão
                  correta para cada registro. Pagamentos em conflito não entram
                  nos totais até a resolução.
                </p>
                {data.conflicts.map((c) => (
                  <section className="panel" key={c.entity + c.key}>
                    <h3>
                      {
                        {
                          project: "Projeto",
                          item: "Item",
                          payment: "Pagamento",
                        }[c.entity]
                      }{" "}
                      em conflito
                    </h3>
                    {c.heads.map((op) => (
                      <button
                        className="conflictchoice"
                        key={op.id}
                        disabled={busy}
                        onClick={() =>
                          void run(async () => {
                            if (
                              !confirm(
                                "Usar esta versão e resolver as demais alternativas?",
                              )
                            )
                              return;
                            await store.write(c.entity, c.key, op.value);
                            notify(
                              "Conflito resolvido e resolução registrada.",
                            );
                          })
                        }
                      >
                        <b>
                          {op.value === null
                            ? "Registro excluído"
                            : "amountCents" in op.value
                              ? money(op.value.amountCents) +
                                " · " +
                                op.value.method
                              : "projectId" in op.value
                                ? op.value.description
                                : op.value.name}
                        </b>
                        <p>
                          {op.value && "supplier" in op.value
                            ? op.value.supplier
                            : ""}
                        </p>
                        <p className="micro">
                          {new Date(op.time).toLocaleString("pt-BR")} ·
                          dispositivo {op.actor.slice(0, 8)}
                        </p>
                        <pre>
                          {JSON.stringify(
                            op.value,
                            (_k, v) =>
                              typeof v === "string" && v.startsWith("data:")
                                ? "[Comprovante preservado]"
                                : v,
                            2,
                          )}
                        </pre>
                        <span className="green">
                          Usar esta versão <ArrowRight />
                        </span>
                      </button>
                    ))}
                  </section>
                ))}
              </>
            )}
            {modal.type === "import" && (
              <ImportPanel
                rows={modal.rows}
                projectId={projectId}
                onRows={(rows) => {
                  setModal({ type: "import", rows });
                }}
                onFinish={() => {
                  setModal(null);
                  notify("Importação concluída.");
                }}
                onError={handleError}
                run={run}
                busy={busy}
              />
            )}
          </div>
        </div>
      )}
      <DataList id="suppliers" values={suppliers} />
      <DataList id="categories" values={categories} />
      <DataList id="methods" values={methods} />
      {project?.columns
        .filter((c) => c.type === "choice")
        .map((c) => (
          <DataList
            key={c.id}
            id={"custom-" + c.id}
            values={projectItems.map((i) => i.custom[c.id] || "")}
          />
        ))}
      {message && (
        <div className="toast" role="status" aria-live="polite">
          {message}
        </div>
      )}
      {busy && (
        <div className="busy-indicator" role="status">
          Salvando / processando…
        </div>
      )}
    </>
  );
}
function ImportPanel({
  rows,
  projectId,
  onRows,
  onFinish,
  onError,
  run,
  busy,
}: {
  rows?: Record<string, unknown>[];
  projectId: string;
  onRows: (rows: Record<string, unknown>[]) => void;
  onFinish: () => void;
  onError: (e: unknown) => void;
  run: (fn: () => Promise<void>) => Promise<void>;
  busy: boolean;
}) {
  let [mapping, setMapping] = useState<Partial<Record<MappingField, string>>>(
      {},
    ),
    [warnings, setWarnings] = useState<string[]>([]),
    [ready, setReady] = useState(false),
    records = useRef<ReturnType<typeof mappedRecords>["records"]>([]);
  useEffect(() => {
    if (!rows?.length) return;
    let normalize = (s: string) =>
      s
        .normalize("NFD")
        .replace(/\p{Diacritic}/gu, "")
        .toLowerCase()
        .replace(/[^a-z0-9]/g, "");
    let map: Partial<Record<MappingField, string>> = {};
    for (let [key, label] of Object.entries(mappingLabels)) {
      let match = Object.keys(rows[0]).find(
        (h) => normalize(h) === normalize(label),
      );
      if (match) map[key as MappingField] = match;
    }
    let headers = Object.keys(rows[0]);
    map.method =
      headers.find((h) =>
        ["pagamento", "metodo", "metododepagamento"].includes(normalize(h)),
      ) || map.method;
    map.date =
      headers.find((h) => ["data", "datadopagamento"].includes(normalize(h))) ||
      map.date;
    setMapping(map);
  }, [rows]);
  return (
    <>
      <p>
        Selecione uma planilha e confira o mapeamento antes de importar. Valores
        já pagos só viram pagamento quando houver data e método.
      </p>
      <label className="form">
        Arquivo XLSX / CSV
        <input
          type="file"
          accept=".xlsx,.csv"
          onChange={(e) => {
            let f = e.target.files?.[0];
            if (f)
              void run(async () => {
                onRows(await spreadsheetRows(f));
                setReady(false);
              });
          }}
        />
      </label>
      {rows?.length ? (
        <>
          <p style={{ marginTop: 20 }}>{rows.length} linhas encontradas.</p>
          <div className="form">
            {Object.entries(mappingLabels).map(([field, label]) => (
              <label key={field}>
                {label}
                {field === "description" ? " *" : ""}
                <select
                  value={mapping[field as MappingField] || ""}
                  onChange={(e) => {
                    setMapping({ ...mapping, [field]: e.target.value });
                    setReady(false);
                  }}
                >
                  <option value="">Não importar</option>
                  {Object.keys(rows[0]).map((h) => (
                    <option key={h}>{h}</option>
                  ))}
                </select>
              </label>
            ))}
          </div>
          <div className="actions">
            <Btn
              disabled={!mapping.description || busy}
              onClick={() => {
                try {
                  let result = mappedRecords(projectId, rows, mapping);
                  records.current = result.records;
                  setWarnings(result.warnings);
                  setReady(true);
                } catch (e) {
                  onError(e);
                }
              }}
            >
              Revisar importação
            </Btn>
            {ready && (
              <Btn
                primary
                disabled={busy || !records.current.length}
                onClick={() =>
                  void run(async () => {
                    await store.batch(records.current);
                    onFinish();
                  })
                }
              >
                Confirmar{" "}
                {records.current.filter((r) => r.entity === "item").length}{" "}
                itens
              </Btn>
            )}
          </div>
          {ready && (
            <div className="notice">
              <p>
                {records.current.filter((r) => r.entity === "payment").length}{" "}
                pagamento(s) inicial(is) serão criados.
              </p>
              {warnings.map((w, n) => (
                <p key={n} className="micro">
                  {w}
                </p>
              ))}
            </div>
          )}
        </>
      ) : (
        rows && <p>Arquivo sem linhas de dados.</p>
      )}
    </>
  );
}
