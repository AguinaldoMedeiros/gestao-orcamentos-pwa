package main

import (
	"io/fs"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestEmbeddedApp(t *testing.T) {
	h := localHandler()
	for _, p := range []string{"/", "/sw.js", "/version.json", "/__health"} {
		r := httptest.NewRequest("GET", appURL+strings.TrimPrefix(p, "/"), nil)
		w := httptest.NewRecorder()
		h.ServeHTTP(w, r)
		if w.Code != 200 {
			t.Fatalf("%s: %d", p, w.Code)
		}
	}
	fs.WalkDir(web, "web", func(path string, d fs.DirEntry, e error) error {
		if e != nil {
			t.Fatal(e)
		}
		if !d.IsDir() && path != "web/index.html" {
			r := httptest.NewRequest("GET", appURL+strings.TrimPrefix(path, "web/"), nil)
			w := httptest.NewRecorder()
			h.ServeHTTP(w, r)
			if w.Code != 200 {
				t.Fatalf("asset %s: %d", path, w.Code)
			}
			if strings.Contains(w.Body.String(), "chatgpt.site") {
				t.Fatalf("external host in %s", path)
			}
		}
		return nil
	})
}
func TestRejectOtherHosts(t *testing.T) {
	r := httptest.NewRequest("GET", "http://attacker.invalid/", nil)
	w := httptest.NewRecorder()
	localHandler().ServeHTTP(w, r)
	if w.Code != 403 {
		t.Fatal(w.Code)
	}
}
