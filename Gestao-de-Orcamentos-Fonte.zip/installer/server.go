package main

import (
	"embed"
	"io/fs"
	"net/http"
)

//go:embed web
var web embed.FS

const appURL = "http://127.0.0.1:47831/"

func localHandler() http.Handler {
	root, _ := fs.Sub(web, "web")
	files := http.FileServer(http.FS(root))
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Host != "127.0.0.1:47831" {
			http.Error(w, "Host inválido", 403)
			return
		}
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("Cache-Control", "no-cache")
		if r.URL.Path == "/__health" {
			w.Header().Set("Content-Type", "text/plain")
			w.Write([]byte("gestao-orcamentos-local-v2"))
			return
		}
		files.ServeHTTP(w, r)
	})
}
