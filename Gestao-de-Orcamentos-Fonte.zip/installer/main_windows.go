//go:build windows

// Per-user installer and launcher for the hosted PWA. No elevated privileges.
package main

import (
	"bytes"
	_ "embed"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"unsafe"
)

//go:embed assets/app.ico
var icon []byte

const appURL = "https://gestao-orcamentos-medeiros.medeiros-agui.chatgpt.site/"

var messageBox = syscall.NewLazyDLL("user32.dll").NewProc("MessageBoxW")

func dialog(text string, flags uintptr) uintptr {
	t, _ := syscall.UTF16PtrFromString("Gestão de Orçamentos")
	b, _ := syscall.UTF16PtrFromString(text)
	r, _, _ := messageBox.Call(0, uintptr(unsafe.Pointer(b)), uintptr(unsafe.Pointer(t)), flags)
	return r
}
func fail(err error) {
	dialog("Não foi possível concluir a operação.\n\n"+err.Error(), 0x10)
	os.Exit(1)
}
func powershell(script string, env []string) error {
	c := exec.Command("powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", script)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	c.Env = append(os.Environ(), env...)
	out, err := c.CombinedOutput()
	if err != nil {
		return fmt.Errorf("%w: %s", err, bytes.TrimSpace(out))
	}
	return nil
}
func browser() string {
	for _, rel := range []string{`Microsoft\Edge\Application\msedge.exe`, `Google\Chrome\Application\chrome.exe`} {
		for _, root := range []string{os.Getenv("ProgramFiles(x86)"), os.Getenv("ProgramFiles"), os.Getenv("LOCALAPPDATA")} {
			if root == "" {
				continue
			}
			p := filepath.Join(root, rel)
			if info, err := os.Stat(p); err == nil && !info.IsDir() {
				return p
			}
		}
	}
	return ""
}
func launch() {
	b := browser()
	if b == "" {
		dialog("Instale Microsoft Edge ou Google Chrome para abrir o aplicativo.\n\n"+appURL, 0x30)
		return
	}
	if err := exec.Command(b, "--app="+appURL).Start(); err != nil {
		fail(err)
	}
}
func main() {
	local := os.Getenv("LOCALAPPDATA")
	if local == "" {
		fail(fmt.Errorf("LOCALAPPDATA não está disponível"))
	}
	folder := filepath.Join(local, "GestaoOrcamentos")
	exe := filepath.Join(folder, "GestaoOrcamentos.exe")
	args := os.Args[1:]
	if len(args) > 0 && args[0] == "--launch" {
		launch()
		return
	}
	if len(args) > 0 && args[0] == "--uninstall" {
		if dialog("Remover os atalhos e o inicializador?\n\nOs dados financeiros no navegador serão preservados.", 0x24) != 6 {
			return
		}
		script := `$ErrorActionPreference='Stop'; $menu=Join-Path ([Environment]::GetFolderPath('Programs')) 'Gestão de Orçamentos';if(Test-Path -LiteralPath $menu){Remove-Item -LiteralPath $menu -Recurse -Force};$desktop=Join-Path ([Environment]::GetFolderPath('Desktop')) 'Gestão de Orçamentos.lnk';if(Test-Path -LiteralPath $desktop){Remove-Item -LiteralPath $desktop -Force};Remove-Item -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\GestaoOrcamentos' -Recurse -Force -ErrorAction SilentlyContinue`
		if err := powershell(script, nil); err != nil {
			fail(err)
		}
		c := exec.Command("powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", `Start-Sleep -Seconds 2; Remove-Item -LiteralPath $env:GORC_FOLDER -Recurse -Force`)
		c.Env = append(os.Environ(), "GORC_FOLDER="+folder)
		c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
		if err := c.Start(); err != nil {
			fail(err)
		}
		return
	}
	if browser() == "" {
		dialog("Este aplicativo precisa de Microsoft Edge ou Google Chrome. Instale um deles antes de continuar.", 0x30)
		return
	}
	if dialog("Instalar Gestão de Orçamentos neste usuário?\n\nSerão criados atalhos na Área de Trabalho e no menu Iniciar. O aplicativo abre em janela própria usando Edge ou Chrome.\n\nInternet é necessária no primeiro acesso para preparar o modo offline. Os dados ficam neste computador, salvo sincronização autorizada.", 0x24) != 6 {
		return
	}
	source, err := os.Executable()
	if err != nil {
		fail(err)
	}
	if err = os.MkdirAll(folder, 0700); err != nil {
		fail(err)
	}
	if !strings.EqualFold(source, exe) {
		in, e := os.Open(source)
		if e != nil {
			fail(e)
		}
		defer in.Close()
		out, e := os.OpenFile(exe, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0700)
		if e != nil {
			fail(e)
		}
		_, e = io.Copy(out, in)
		closeErr := out.Close()
		if e != nil {
			fail(e)
		}
		if closeErr != nil {
			fail(closeErr)
		}
	}
	ico := filepath.Join(folder, "app.ico")
	if err = os.WriteFile(ico, icon, 0600); err != nil {
		fail(err)
	}
	script := `$ErrorActionPreference='Stop';$shell=New-Object -ComObject WScript.Shell;$menu=Join-Path ([Environment]::GetFolderPath('Programs')) 'Gestão de Orçamentos';[void](New-Item -ItemType Directory -Path $menu -Force);$paths=@((Join-Path $menu 'Gestão de Orçamentos.lnk'),(Join-Path ([Environment]::GetFolderPath('Desktop')) 'Gestão de Orçamentos.lnk'));foreach($path in $paths){$s=$shell.CreateShortcut($path);$s.TargetPath=$env:GORC_EXE;$s.Arguments='--launch';$s.WorkingDirectory=$env:GORC_FOLDER;$s.IconLocation=$env:GORC_ICON;$s.Description='Gestão de orçamentos e pagamentos - dados locais';$s.Save()};$u=$shell.CreateShortcut((Join-Path $menu 'Desinstalar.lnk'));$u.TargetPath=$env:GORC_EXE;$u.Arguments='--uninstall';$u.IconLocation=$env:GORC_ICON;$u.Save();$r='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\GestaoOrcamentos';[void](New-Item -Path $r -Force);New-ItemProperty -Path $r -Name DisplayName -Value 'Gestão de Orçamentos' -PropertyType String -Force|Out-Null;New-ItemProperty -Path $r -Name DisplayVersion -Value '1.0.0' -PropertyType String -Force|Out-Null;New-ItemProperty -Path $r -Name UninstallString -Value ('"'+$env:GORC_EXE+'" --uninstall') -PropertyType String -Force|Out-Null;New-ItemProperty -Path $r -Name InstallLocation -Value $env:GORC_FOLDER -PropertyType String -Force|Out-Null;New-ItemProperty -Path $r -Name DisplayIcon -Value $env:GORC_ICON -PropertyType String -Force|Out-Null;New-ItemProperty -Path $r -Name NoModify -Value 1 -PropertyType DWord -Force|Out-Null;New-ItemProperty -Path $r -Name NoRepair -Value 1 -PropertyType DWord -Force|Out-Null`
	if err = powershell(script, []string{"GORC_EXE=" + exe, "GORC_FOLDER=" + folder, "GORC_ICON=" + ico}); err != nil {
		fail(err)
	}
	dialog("Instalação concluída.\n\nAbra pelo atalho da Área de Trabalho ou do menu Iniciar. No primeiro acesso, aguarde o carregamento completo para preparar o uso offline.\n\nNão limpe os dados do site sem exportar um backup.", 0x40)
	launch()
}
