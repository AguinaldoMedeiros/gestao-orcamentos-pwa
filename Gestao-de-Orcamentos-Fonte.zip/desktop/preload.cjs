const {contextBridge, ipcRenderer} = require('electron');
contextBridge.exposeInMainWorld('desktopApp',Object.freeze({
 ready:result=>ipcRenderer.invoke('app:ready',result),
 info:()=>ipcRenderer.invoke('app:info'),
 checkUpdate:()=>ipcRenderer.invoke('app:update-check'),
 openRelease:()=>ipcRenderer.invoke('app:release-open')
}));
