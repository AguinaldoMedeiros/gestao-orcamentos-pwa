const {app, BrowserWindow, protocol, net, ipcMain, dialog, shell, session, Menu} = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const {pathToFileURL} = require('node:url');
const {APP_ORIGIN,resolveAsset}=require('./assets.cjs');
const smokeMode=process.argv.includes('--smoke-test');
const folder = path.join(app.getPath('appData'),smokeMode?'GestaoOrcamentos-QA':'GestaoOrcamentos');
fs.mkdirSync(folder,{recursive:true});
app.setPath('userData',folder);
app.setPath('sessionData',path.join(folder,'perfil'));
fs.mkdirSync(app.getPath('sessionData'),{recursive:true});
let smokeTimer;
const logPath=path.join(folder,'inicializacao.log');
function log(message){fs.appendFileSync(logPath,new Date().toISOString()+' '+message+'\n');}
process.on('uncaughtException',error=>{log(String(error.stack||error));dialog.showErrorBox('Gestão de Orçamentos','Não foi possível iniciar. Consulte '+logPath);app.quit();});
protocol.registerSchemesAsPrivileged([{scheme:'orcamentos',privileges:{standard:true,secure:true,supportFetchAPI:true,stream:true}}]);
let window;
let releaseURL='https://github.com/AguinaldoMedeiros/gestao-orcamentos-pwa/releases/latest';
const csp="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; frame-src blob:; object-src blob:; base-uri 'self'; form-action 'self'";
function trusted(event){if(!event.senderFrame || !event.senderFrame.url.startsWith(APP_ORIGIN+'/'))throw new Error('Origem não autorizada');}
async function createWindow(){
 window = new BrowserWindow({width:1380,height:900,minWidth:800,minHeight:600,title:'Gestão de Orçamentos',show:false,backgroundColor:'#f4f7fb',icon:path.join(__dirname,'app.ico'),webPreferences:{preload:path.join(__dirname,'preload.cjs'),nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true}});
 window.webContents.setWindowOpenHandler(()=>({action:'deny'}));
 window.webContents.on('will-navigate',(event,url)=>{if(!url.startsWith(APP_ORIGIN+'/'))event.preventDefault();});
 window.webContents.on('will-attach-webview',event=>event.preventDefault());
 window.webContents.on('render-process-gone',(_event,details)=>{log('Renderizador encerrado: '+details.reason);dialog.showErrorBox('Gestão de Orçamentos','A interface foi encerrada. Reabra o aplicativo. Diagnóstico: '+logPath);});
 window.on('closed',()=>{window=null;});
 await window.loadURL(APP_ORIGIN+'/');
 if(!smokeMode) window.show();
 log('Interface carregada do pacote '+app.getVersion());
}
if(!app.requestSingleInstanceLock()){app.quit();}else{
 app.on('second-instance',()=>{if(window){if(window.isMinimized())window.restore();window.focus();}});
 app.whenReady().then(async()=>{
  app.setAppUserModelId('br.gestao.orcamentos');
  Menu.setApplicationMenu(null);
  protocol.handle('orcamentos',async request=>{
   if(request.method!=='GET'&&request.method!=='HEAD')return new Response('Método inválido',{status:405});
   try{
    const file=resolveAsset(path.join(app.getAppPath(),'dist'),request.url);
    const response=await net.fetch(pathToFileURL(file).toString());
    const headers=new Headers(response.headers);headers.set('Content-Security-Policy',csp);headers.set('X-Content-Type-Options','nosniff');
    return new Response(response.body,{status:response.status,headers});
   }catch(error){log('Falha de recurso: '+request.url+' '+error);return new Response('Recurso indisponível',{status:404});}
  });
  session.defaultSession.setPermissionRequestHandler((_wc,permission,callback)=>callback(permission==='persistent-storage'));
  session.defaultSession.setPermissionCheckHandler((_wc,permission)=>permission==='persistent-storage');
  ipcMain.handle('app:info',event=>{trusted(event);return{version:app.getVersion(),dataDirectory:folder,origin:APP_ORIGIN,smokeMode};});
  ipcMain.handle('app:ready', (event,result)=>{trusted(event);if(smokeMode){if(!result || result.storage!==true || result.ui!==true)throw new Error('Autoteste falhou');fs.writeFileSync(path.join(folder,'smoke-ok.json'),JSON.stringify({version:app.getVersion(),origin:APP_ORIGIN,storage:true,ui:true,offline:true,previous:result.previous===true}));clearTimeout(smokeTimer);setTimeout(()=>app.quit(),100);}return true;});
  if(smokeMode){session.defaultSession.webRequest.onBeforeRequest({urls:['http://*/*','https://*/*']},(_details,callback)=>callback({cancel:true}));smokeTimer=setTimeout(()=>{log('Timeout de autoteste');app.exit(1);},30000);}

  ipcMain.handle('app:update-check',async event=>{
   trusted(event);
   try{
    const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),10000);
    let response;try{response=await net.fetch('https://api.github.com/repos/AguinaldoMedeiros/gestao-orcamentos-pwa/releases/latest',{headers:{Accept:'application/vnd.github+json'},signal:controller.signal});}finally{clearTimeout(timer);}
    if(!response.ok)throw new Error('Sem release publicada');
    const data=await response.json();const version=String(data.tag_name).replace(/^v/,'');
    const parts=s=>s.split('.').map(Number);const a=parts(version),b=parts(app.getVersion());
    const available=a.length===3&&a.every(Number.isInteger)&&a.some((v,i)=>v>b[i]&&a.slice(0,i).every((n,j)=>n===b[j]));
    return{available,version,message:available?'Versão '+version+' disponível. Baixe o instalador no GitHub.':'Você está na versão '+app.getVersion()+'.'};
   }catch{return{available:false,message:'Não foi possível consultar o GitHub. O aplicativo continua funcionando offline.'};}
  });
  ipcMain.handle('app:release-open',event=>{trusted(event);return shell.openExternal(releaseURL);});
  await createWindow();
 }).catch(error=>{log(String(error.stack||error));dialog.showErrorBox('Gestão de Orçamentos','Falha ao carregar os arquivos internos. Diagnóstico: '+logPath);app.quit();});
 app.on('window-all-closed',()=>app.quit());
}
