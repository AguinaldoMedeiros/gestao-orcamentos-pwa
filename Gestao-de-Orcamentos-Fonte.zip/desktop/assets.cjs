const path = require('node:path');
const APP_ORIGIN = 'orcamentos://app';
function resolveAsset(root, input) {
 const url = new URL(input);
 if(url.protocol !== 'orcamentos:' || url.hostname !== 'app' || url.port || url.username || url.password) throw new Error('Origem inválida');
 const decoded = decodeURIComponent(url.pathname);
 if(decoded.includes('\\') || decoded.includes('\0') || decoded.split('/').includes('..')) throw new Error('Caminho inválido');
 const relative = decoded === '/' ? 'index.html' : decoded.replace(/^\/+/, '');
 const result = path.resolve(root, relative);
 if(!result.startsWith(path.resolve(root)+path.sep)) throw new Error('Caminho inválido');
 return result;
}
module.exports={APP_ORIGIN,resolveAsset};
