# Modelo de segurança

O aplicativo é local primeiro. A hospedagem distribui o código; não mantém o banco financeiro. Uma atualização do código publicado tem acesso ao banco do aplicativo, portanto proteja a conta do GitHub e revise as publicações.

Pareie somente dispositivos de confiança. A aprovação compartilha todos os projetos e comprovantes. Uma pessoa com um convite e sua resposta pode participar da sessão; compare a chave de conferência em um canal de confiança. Desconectar termina o canal, mas não apaga cópias já recebidas.

Os registros são validados antes de uma transação IndexedDB. O arquivo anexado é exibido como imagem ou PDF; HTML/SVG não são aceitos. Não há execução de comandos recebidos por sincronização. Conflitos preservam suas versões até a resolução explícita.

Não há autenticação local, senha do aplicativo nem criptografia do banco em repouso. Use proteção da conta do sistema operacional, criptografia de disco e backups protegidos conforme a sensibilidade dos seus dados.
