# Gestão de Orçamentos — PWA

Aplicativo React + TypeScript instalável, com funcionamento offline após o primeiro carregamento, IndexedDB, comprovantes locais e sincronização WebRTC entre dispositivos autorizados.

## Desenvolvimento

Requisitos: Node.js 22 ou superior.

```sh
npm ci
npm test
npm run dev
```

Produção: `npm run build`. Publique **a pasta dist inteira** em HTTPS. A aplicação usa caminhos relativos e funciona em GitHub Pages em um subdiretório.

## Instalação

No Windows, abra no Edge ou Chrome e escolha **Instalar** no topo ou no menu do navegador. A PWA abre em uma janela própria, com atalho no menu Iniciar. No iPhone, use Safari > Compartilhar > Adicionar à Tela de Início > Abrir como App. A instalação sempre depende de uma ação do usuário. Há também um instalador Windows em `public/downloads`: ele cria atalhos e abre a PWA via Edge/Chrome em janela própria. Não instala um navegador nem registra a PWA pelo usuário. O primeiro carregamento precisa de internet. O executável é compilado do código em `installer/` e não possui assinatura digital.

## Atualização pelo GitHub

O workflow `.github/workflows/pages.yml` testa, compila e publica em GitHub Pages a cada push em `main`. Antes da primeira execução, em Settings > Pages escolha GitHub Actions como origem. Repositórios privados podem exigir um plano do GitHub compatível com Pages. Não publique bancos, backups ou comprovantes no repositório.

O service worker verifica um pacote novo no mesmo endereço e prepara todos os arquivos antes de disponibilizar **Atualizar e reabrir**. O banco IndexedDB não é apagado na atualização. O código hash do pacote muda mesmo quando a versão de produto não muda. Para uma release com ZIP compilado, publique uma tag `v1.0.0` e execute o workflow de release. Não há chaves privadas nem tokens embutidos no aplicativo.

## Armazenamento

- Banco: IndexedDB `gestao-orcamentos`, versão de esquema 1.
- `ops`: histórico imutável com projetos, itens, pagamentos, exclusões e recibos.
- `meta`: identificador do dispositivo e preferências locais.
- Valores monetários: inteiros em centavos.
- Comprovantes: PNG/JPG/WEBP/GIF/PDF, até 5 MB por arquivo, preservados no backup `.gorc`.
- Cache Storage: apenas arquivos do aplicativo.
- Os dados não são enviados ao GitHub ou à hospedagem. As conexões de sincronização só são abertas por ação explícita.
- O navegador pode negar armazenamento persistente. Limpar os dados do site, apagar o perfil ou mudar a origem pode perder os dados. Faça backups. Não há criptografia em repouso.

## Sincronização distribuída

Cada instância guarda seu próprio histórico. Não há banco central. As alterações são identificadas por UUID e têm relações causais explícitas; a entrega repetida de um evento não duplica pagamentos. Alterações concorrentes no mesmo registro viram um conflito, que exige escolha manual. Pagamentos com versões concorrentes ficam fora dos totais até serem resolvidos. Dois pagamentos distintos podem, por concorrência, ultrapassar o orçamento: ambos são preservados e a interface alerta para revisão.

### Pareamento sem servidor de sinalização

1. Abra **Sincronização** nos computadores A e B.
2. A cria convite e envia o código para B por um canal de confiança.
3. B cola e aceita o convite, gerando a resposta.
4. A cola a resposta e seleciona **Aplicar resposta**.
5. Compare a chave curta nas duas telas e confirme em ambas.

Os códigos contêm informação de rede e um segredo temporário. Não os publique. Somente depois das duas confirmações os históricos financeiros são enviados. O canal WebRTC usa DTLS; as mensagens da aplicação também usam AES-256-GCM. As transferências são divididas em blocos e limitadas a 45 MB de conteúdo por envio.

A sincronização acontece enquanto as instâncias estão abertas, autorizadas e conectadas. Os eventos permanecem no banco quando offline. Ao fechar/reabrir uma instância, é preciso refazer o pareamento; não há descoberta automática nem reconexão sem sinalização. Uma malha de conexões autorizadas retransmite as alterações entre os pares sem duplicá-las.

Na mesma rede, a conexão direta normalmente é possível; firewalls, isolamento Wi-Fi e políticas do navegador podem bloqueá-la. Pela internet, configure seu próprio servidor STUN/TURN nas opções avançadas. Nenhum servidor público é usado por padrão. Um TURN pode retransmitir os pacotes criptografados. Credenciais TURN permanecem nos metadados locais. A disponibilidade de uma conexão direta não é garantida.

## Backup e importação

A restauração completa cria eventos de exclusão/atualização e pode se propagar aos pares conectados. O histórico anterior continua preservado. A opção mesclar mantém os históricos recebidos e mostra conflitos. Backups com conflitos não podem ser restaurados como substituição até serem revisados.

Importação de XLSX/CSV possui mapeamento de colunas e revisão antes de gravar. Pagamento inicial exige valor, data e método; valores excedentes são omitidos e avisados para registro posterior com confirmação. Exportação XLSX contém os itens filtrados e uma aba de pagamentos. O PDF exporta o relatório filtrado.

## Escopo e validação

Esta entrega é uma versão inicial operacional. Testes automatizados cobrem centavos, pagamentos parciais, persistência, duplicação de eventos, conflitos, exclusões, comprovantes e regras de importação. WebRTC entre redes diferentes depende da infraestrutura escolhida e deve ser validado nas redes de destino. Não foi implementada descoberta automática em segundo plano, hospedagem de TURN, notificação local de vencimentos nem os módulos avançados de propostas e comparação de fornecedores da fase 3.
